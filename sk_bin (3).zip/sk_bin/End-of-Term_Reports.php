<?php
 include('includes/header.php');

 include('includes/navbar.php');
 include('includes/topbar.php');
 ?>



<div class="container-fluid mt-4">
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">End-of-Term Project Summary</h6>
        </div>

        <div class="card-body">
            <div class="table-responsive">
                <table id="endOfTermTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th>Project Title</th>
                            <th>Barangay</th>
                            <th>Date Implemented</th>
                            <th>Total Budget</th>
                            <th>Youth Benefited</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Youth Leadership Seminar</td>
                            <td>Barangay Uno</td>
                            <td>2023-02-15</td>
                            <td>₱12,000.00</td>
                            <td>55</td>
                            <td>Completed</td>
                        </tr>
                        <tr>
                            <td>SK Sports Fest</td>
                            <td>Barangay Dos</td>
                            <td>2023-04-20</td>
                            <td>₱18,000.00</td>
                            <td>120</td>
                            <td>Completed</td>
                        </tr>
                        <tr>
                            <td>Tree Planting Project</td>
                            <td>Barangay Tres</td>
                            <td>2023-06-10</td>
                            <td>₱5,000.00</td>
                            <td>30</td>
                            <td>Completed</td>
                        </tr>
                        <tr>
                            <td>Year-End Youth Summit</td>
                            <td>Federation-wide</td>
                            <td>2024-12-10</td>
                            <td>₱25,000.00</td>
                            <td>200</td>
                            <td>Upcoming</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>



    
<?php

include('includes/footer.php');
?>


<!-- DataTables JS (after jQuery & Bootstrap JS) -->
<script>
    $(document).ready(function () {
        $('#endOfTermTable').DataTable({
            responsive: true,
            autoWidth: false,
            ordering: true,
            searching: true,
            paging: true
        });
    });
</script>
