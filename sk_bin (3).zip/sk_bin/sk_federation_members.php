<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
    .sk-card {
        transition: transform 0.2s, box-shadow 0.3s;
        border-radius: 1rem;
        background: linear-gradient(135deg, #f8f9fa, #e0f7fa);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .sk-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 25px rgba(0, 0, 0, 0.1);
    }

    .sk-card h5 {
        font-weight: 700;
        color: #0d6efd;
    }

    .sk-card .card-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
    }

    .sk-card i {
        font-size: 2rem;
        color: #0d6efd;
        margin-bottom: 10px;
    }

    a.text-decoration-none:hover h5 {
        text-decoration: underline;
    }
</style>

<div class="container py-5">
    <div class="row g-4 justify-content-center">

        <!-- Federation Card -->
        <div class="col-sm-6 col-md-4 col-lg-3">
            <a href="sk_federation.php" class="text-decoration-none">
                <div class="card sk-card p-3 text-center h-100">
                    <div class="card-body">
                        <i class="fas fa-users-cog"></i>
                        <h5 class="mt-2">SK Federation Officials</h5>
                    </div>
                </div>
            </a>
        </div>

        <!-- Other Barangays -->
        <?php
        $barangays = [
            "Amontay" => "brgy_amontay.php",
            "Bagroy" => "brgy_bagroy.php",
            "Bi-ao" => "brgy_biao.php",
            "Canmoros" => "brgy_canmoros.php",
            "Enclaro" => "brgy_enclaro.php",
            "Marina" => "brgy_marina.php",
            "Pagla-um" => "brgy_paglaum.php",
            "Payao" => "brgy_payao.php",
            "Progreso" => "brgy_progreso.php",
            "San Jose" => "brgy_sanjose.php",
            "San Juan" => "brgy_sanjuan.php",
            "San Pedro" => "brgy_sanpedro.php",
            "San Teodoro" => "brgy_santeodoro.php",
            "San Vicente" => "brgy_sanvicente.php",
            "Santo Rosario" => "brgy_santorosario.php",
            "Santol" => "brgy_santol.php"
        ];

        foreach ($barangays as $brgy => $link) {
            echo "
            <div class='col-sm-6 col-md-4 col-lg-3'>
                <a href='{$link}' class='text-decoration-none'>
                    <div class='card sk-card p-3 text-center h-100'>
                        <div class='card-body'>
                            <i class='fas fa-user-friends'></i>
                            <h5 class='mt-2'>Brgy. {$brgy} SK Officials</h5>
                        </div>
                    </div>
                </a>
            </div>";
        }
        ?>
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
