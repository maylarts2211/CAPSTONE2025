 <!-- Submission Form -->
 <?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
 ?>

    
    <div class="card shadow mb-4">
        <div class="card-header py-3"><h6 class="m-0 font-weight-bold text-primary">Submit New Proposal</h6></div>
        <div class="card-body">
            <form id="proposalForm">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>Barangay</label>
                        <input type="text" class="form-control" id="barangay_name" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label>Project Title</label>
                        <input type="text" class="form-control" id="proposal_title" required>
                    </div>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea class="form-control" id="proposal_description" rows="3" required></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label>Total Budget (₱)</label>
                        <input type="number" class="form-control" id="proposal_budget" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Date Implemented</label>
                        <input type="date" class="form-control" id="proposal_date" required>
                    </div>
                    <div class="form-group col-md-4">
                        <label>Youth Benefited</label>
                        <input type="number" class="form-control" id="proposal_benefit" required>
                    </div>
                </div>
                <button type="button" class="btn btn-success" onclick="submitProposal()">Submit Proposal</button>
            </form>
        </div>
    </div>
