<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
?>

<div class="container-fluid mt-4">
    <h2 class="text-center">SK Federation Form Template</h2>
    <p class="text-center">Use this form to add or update reports, track progress, or manage SK Federation data.</p>

    <div class="row justify-content-center">
        <div class="col-md-8">
            <!-- Form to add or update report -->
            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-edit"></i> Add / Update Report</h5>

                    <form action="submit_report.php" method="POST">
                        <div class="form-group">
                            <label for="reportTitle">Report Title</label>
                            <input type="text" class="form-control" id="reportTitle" name="reportTitle" required placeholder="Enter report title">
                        </div>

                        <div class="form-group">
                            <label for="reportDate">Report Date</label>
                            <input type="date" class="form-control" id="reportDate" name="reportDate" required>
                        </div>

                        <div class="form-group">
                            <label for="reportCategory">Report Category</label>
                            <select class="form-control" id="reportCategory" name="reportCategory" required>
                                <option value="financial">Financial</option>
                                <option value="progress">Barangay Progress</option>
                                <option value="activity">Community Activity</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="reportDescription">Description</label>
                            <textarea class="form-control" id="reportDescription" name="reportDescription" rows="4" required placeholder="Enter a brief description of the report"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="reportFile">Upload Report (PDF)</label>
                            <input type="file" class="form-control-file" id="reportFile" name="reportFile" required accept=".pdf">
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Submit Report</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<?php
include('includes/footer.php');
?>
