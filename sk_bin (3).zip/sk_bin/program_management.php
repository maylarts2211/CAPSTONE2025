<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>

<div class="container-fluid mt-4">

    <!-- Page Heading -->
  

    <!-- Subsection Navigation -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="row text-center">
                <div class="col-md-2 mb-2">
                    <a href="sk_funds.php" class="btn btn-outline-primary btn-block">CBYDP</a>
                </div>
                <div class="col-md-2 mb-2">
                    <a href="liquidation_report.php" class="btn btn-outline-primary btn-block">ABYIP</a>
                </div>
               
            </div>
        </div>
    </div>

</div>


<?php
include('includes/footer.php');
?>
