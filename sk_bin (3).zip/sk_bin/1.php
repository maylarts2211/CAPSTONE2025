<?php
// db_connect.php
$host = 'localhost';
$db   = 'sk_bin';
$user = '';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add SK Officer</title>

    <!-- sb-admin-2 CSS -->
    <link rel="stylesheet" href="css/sb-admin-2.css">
    <link rel="stylesheet" href="css/sb-admin-2.min.css">

    <!-- Bootstrap (if needed) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="card shadow-sm w-100" style="max-width: 500px;">
        <div class="card-body">
            <h4 class="card-title text-center text-primary mb-4">Add SK Officer</h4>

            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                require 'connect.php'; // check this file is correct

                $full_name = $_POST['full_name'] ?? '';
                $position = $_POST['position'] ?? '';
                $term_start = $_POST['term_start'] ?? '';
                $term_end = $_POST['term_end'] ?? '';

                if ($full_name && $position && $term_start && $term_end) {
                    $stmt = $pdo->prepare("INSERT INTO sk_officers (full_name, position, term_start, term_end) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$full_name, $position, $term_start, $term_end]);

                    echo "<div class='alert alert-success'>Officer added successfully!</div>";
                } else {
                    echo "<div class='alert alert-danger'>All fields are required.</div>";
                }
            }
            ?>

            <form method="post" action="">
                <div class="mb-3">
                    <label class="form-label">Full Name</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Position</label>
                    <input type="text" name="position" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Term Start</label>
                    <input type="date" name="term_start" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Term End</label>
                    <input type="date" name="term_end" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary w-100">Add Officer</button>
            </form>
        </div>
    </div>
</div>

<!-- JS Dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>
</body>
</html>
