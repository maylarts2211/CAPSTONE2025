<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
 ?>

    
   

 <!-- Begin Page Content -->
<div class="container-fluid">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
  <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
  <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
    <i class="fas fa-download fa-sm text-white-50"></i> Generate Report
  </a>
</div>

<!-- Stats Summary Cards -->
<div class="row mb-4">
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-primary shadow h-100 py-2">
      <div class="card-body">
        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Barangays</div>
        <div class="h5 mb-0 font-weight-bold text-gray-800">20</div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
      <div class="card-body">
        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Reports Submitted</div>
        <div class="h5 mb-0 font-weight-bold text-gray-800">53</div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-warning shadow h-100 py-2">
      <div class="card-body">
        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Active Tasks</div>
        <div class="h5 mb-0 font-weight-bold text-gray-800">7</div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-danger shadow h-100 py-2">
      <div class="card-body">
        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Pending Complaints</div>
        <div class="h5 mb-0 font-weight-bold text-gray-800">4</div>
      </div>
    </div>
  </div>
</div>

<!-- Row: Recent Submissions & Tasks Overview -->
<div class="row">
  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header bg-info text-white">
        📁 Recent Submissions
      </div>
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">Barangay 1 - Accomplishment Report</li>
          <li class="list-group-item">Barangay 5 - Budget Proposal</li>
          <li class="list-group-item">Barangay 3 - Activity Summary</li>
        </ul>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header bg-warning text-dark">
        📌 Tasks Overview
      </div>
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">Finalize Federation Budget – <span class="badge bg-success">Done</span></li>
          <li class="list-group-item">Coordinate Sports Program – <span class="badge bg-danger">Pending</span></li>
          <li class="list-group-item">Barangay Visitation – <span class="badge bg-warning text-dark">Ongoing</span></li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- Row: Quick Summary & Announcements -->
<div class="row">
  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header bg-success text-white">
        🗘️ Quick Report Summary
      </div>
      <div class="card-body">
        <ul>
          <li><strong>Total Budget Used:</strong> ₱150,000</li>
          <li><strong>Ongoing Projects:</strong> 3 out of 5</li>
          <li><strong>Urgent:</strong> Fund liquidation due April 30</li>
        </ul>
      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card mb-4">
      <div class="card-header bg-secondary text-white">
        📢 Recent Announcements
      </div>
      <div class="card-body">
        <ul class="list-group">
          <li class="list-group-item">Meeting on May 1 at SK Hall</li>
          <li class="list-group-item">New guidelines on event planning</li>
          <li class="list-group-item">Submission deadlines extended</li>
        </ul>
      </div>
    </div>
  </div>
</div>

<!-- Complaint Alerts -->
<div class="card mb-4">
  <div class="card-header bg-danger text-white">
    📬 Complaint Alerts
  </div>
  <div class="card-body">
    <ul class="list-group">
      <li class="list-group-item">Barangay 4 – Misused funds complaint (Escalated)</li>
      <li class="list-group-item">Barangay 7 – Event disturbance report (Pending)</li>
    </ul>
  </div>
</div>
</div>
</div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

    </div>
    <!-- End of Page Wrapper -->

   
   
<?php
include('includes/scripts.php');
include('includes/footer.php');
?>