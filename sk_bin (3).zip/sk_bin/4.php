<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Member Form</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Bootstrap & FontAwesome -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>
        .form-group {
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

<div class="container mt-4">
    <form id="member-form">
        <h4>Basic Information</h4>
        <div class="form-group">
            <label>First Name</label>
            <input name="firstname" type="text" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Middle Name</label>
            <input name="middlename" type="text" class="form-control">
        </div>
        <div class="form-group">
            <label>Last Name</label>
            <input name="lastname" type="text" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Gender</label>
            <select name="gender" class="custom-select" required>
                <option>Male</option>
                <option>Female</option>
            </select>
        </div>
        <div class="form-group">
            <label>Contact #</label>
            <input name="contact" type="text" class="form-control" required>
        </div>

        <h4>Location</h4>
        <div class="form-group">
            <label>Phase</label>
            <select name="phase_id" class="form-control select2" required>
                <option disabled selected>Please Select</option>
                <option value="1">Phase 1</option>
                <option value="2">Phase 2</option>
            </select>
        </div>
        <div class="form-group">
            <label>Block #</label>
            <input name="block" type="text" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Lot #</label>
            <input name="lot" type="text" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Status</label>
            <select name="status" class="custom-select" required>
                <option value="1">Active</option>
                <option value="0">Inactive</option>
            </select>
        </div>

        <h5>Additional Info</h5>
        <div class="form-group"><label>Nickname</label><input name="nickname" type="text" class="form-control"></div>
        <div class="form-group"><label>Civil Status</label><input name="civil_status" type="text" class="form-control"></div>
        <div class="form-group"><label>Date of Birth</label><input name="date_of_birth" type="date" class="form-control"></div>
        <div class="form-group"><label>Place of Birth</label><input name="place_of_birth" type="text" class="form-control"></div>
        <div class="form-group"><label>Email</label><input name="email" type="email" class="form-control"></div>
        <div class="form-group"><label>Facebook</label><input name="facebook" type="text" class="form-control"></div>
        <div class="form-group"><label>TIN Number</label><input name="tin_number" type="text" class="form-control"></div>
        <div class="form-group"><label>Educational Attainment</label><input name="educational_attainment" type="text" class="form-control"></div>
        <div class="form-group"><label>Occupation</label><input name="occupation" type="text" class="form-control"></div>
        <div class="form-group"><label>Years of Residency</label><input name="residency_years" type="number" class="form-control"></div>
        <div class="form-group"><label>Months of Residency</label><input name="residency_months" type="number" class="form-control"></div>
        <div class="form-group"><label>Position (if Officer)</label><input name="position" type="text" class="form-control"></div>

        <div class="text-right">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
</div>

<!-- JS Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script>
$(document).ready(function(){
    $('.select2').select2({ width: '100%' });

    $('#member-form').submit(function(e){
        e.preventDefault();
        $.ajax({
            url: 'save_member.php',
            method: 'POST',
            data: $(this).serialize(),
            success: function(response){
                alert(response);
                $('#member-form')[0].reset();
                $('.select2').val(null).trigger('change');
            },
            error: function(){
                alert('An error occurred.');
            }
        });
    });
});
</script>
</body>
</html>
