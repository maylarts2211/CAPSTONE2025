<?php
include('includes/connect.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize inputs
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $age = (int) $_POST['age'];
    $gender = mysqli_real_escape_string($conn, $_POST['gender']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $contact_number = mysqli_real_escape_string($conn, $_POST['contact_number']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $education = mysqli_real_escape_string($conn, $_POST['education']);
    $term_start = mysqli_real_escape_string($conn, $_POST['term_start']);
    $term_end = mysqli_real_escape_string($conn, $_POST['term_end']);
    $created_at = date('Y-m-d H:i:s');

    $query = "INSERT INTO brgy_amontay 
        (full_name, age, gender, address, contact_number, email, education, term_start, term_end, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $query);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "sissssssss",
            $full_name,
            $age,
            $gender,
            $address,
            $contact_number,
            $email,
            $education,
            $term_start,
            $term_end,
            $created_at
        );

        if (mysqli_stmt_execute($stmt)) {
            // Success - Redirect back to main page
            header("Location: amontay_officers.php?success=1");
            exit();
        } else {
            echo "Error executing query: " . mysqli_stmt_error($stmt);
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($conn);
    }
} else {
    echo "Invalid request method.";
}

mysqli_close($conn);
?>
