<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');

$conn = new mysqli("localhost", "root", "", "sk_bin");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $meeting_type = $_POST['meeting_type'];
    $meeting_datetime = $_POST['meeting_datetime'];
    $location = $_POST['location'];
    $presiding_officer = $_POST['presiding_officer'];
    $secretary = $_POST['secretary'];
    $present_count = (int)$_POST['present_count'];
    $agenda_summary = $_POST['agenda_summary'];
    $agenda_1 = $_POST['agenda_1'];
    $agenda_2 = $_POST['agenda_2'];
    $agenda_3 = $_POST['agenda_3'];
    $agenda_4 = $_POST['agenda_4'];
    $other_matters = $_POST['other_matters'];
    $adjournment = $_POST['adjournment'];
    $attachment = '';

    if (!empty($_FILES['file_attachment']['name'])) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_name = basename($_FILES['file_attachment']['name']);
        $target_file = $upload_dir . time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $file_name);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['file_attachment']['tmp_name'], $target_file)) {
                $attachment = basename($target_file);
            } else {
                echo "<script>alert('Error uploading the file.');</script>";
            }
        } else {
            echo "<script>alert('Invalid file type. Allowed: pdf, doc, docx, jpg, jpeg, png');</script>";
        }
    }

    $stmt = $conn->prepare("INSERT INTO tbl_mom 
        (meeting_type, meeting_datetime, location, presiding_officer, secretary, present_count, agenda_summary, agenda_1, agenda_2, agenda_3, agenda_4, other_matters, adjournment, attachment) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssissssssss", 
        $meeting_type, $meeting_datetime, $location, $presiding_officer, $secretary, $present_count, 
        $agenda_summary, $agenda_1, $agenda_2, $agenda_3, $agenda_4, $other_matters, $adjournment, $attachment);

    if ($stmt->execute()) {
        echo "<script>alert('Minutes of Meeting added successfully!');</script>";
    } else {
        echo "<script>alert('Failed to add Minutes of Meeting.');</script>";
    }
    $stmt->close();
}
?>
<div class="container  mb-3">
<!-- Add Minutes & Archive Buttons -->
  <div class="card shadow mb-4">
        <div class="card-body">
            <div class="row text-center">
                <div class="col-md-2 mb-2">
                    <a href="MOM.php" class="btn btn-outline-primary btn-block">MOM</a>
                </div>
                <div class="col-md-2 mb-2">
                    <a href="liquidation_report.php" class="btn btn-outline-primary btn-block">Schedule Meeting</a>
                </div>
                 
                 <div class="col-md-2 mb-2">
                    <a href="liquidation_report.php" class="btn btn-outline-primary btn-block">Resolution</a>
                </div>
                <div class="col-md-2 mb-2">
                    <a href="forms.php" class="btn btn-outline-primary btn-block">Forms</a>
                </div>
               
            </div>
        </div>
    </div>


    <div class="d-flex justify-content-start gap-2">
        <button class="btn btn-primary mr-2" data-toggle="modal" data-target="#addMinutesModal">
            <i class="fas fa-plus"></i> Add Minutes
        </button>
        <button class="btn btn-secondary" onclick="window.location.href='MOM_archive.php';">
            <i class="fas fa-archive"></i> Archive
        </button>
    </div>
</div>

<!-- Add Minutes Modal -->
<div class="modal fade" id="addMinutesModal" tabindex="-1" role="dialog" aria-labelledby="addMinutesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content" style="max-height: 90vh; overflow-y: auto;">
            <form method="POST" enctype="multipart/form-data">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title">Add Minutes of Meeting</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
                    <div class="row">
                        <!-- Left Column -->
                        <div class="col-md-6">
                            <?php
                            $leftFields = [
                                ['label' => 'Meeting Type', 'name' => 'meeting_type', 'type' => 'text', 'placeholder' => 'e.g., Regular Monthly Meeting', 'required' => true],
                                ['label' => 'Date & Time', 'name' => 'meeting_datetime', 'type' => 'datetime-local', 'required' => true],
                                ['label' => 'Location', 'name' => 'location', 'type' => 'text', 'required' => true],
                                ['label' => 'Presiding Officer', 'name' => 'presiding_officer', 'type' => 'text', 'required' => true],
                                ['label' => 'Secretary', 'name' => 'secretary', 'type' => 'text', 'required' => true],
                                ['label' => 'No. of Attendees', 'name' => 'present_count', 'type' => 'number', 'min' => 1, 'required' => true],
                            ];
                            foreach ($leftFields as $field) {
                                echo "<div class='form-group'>";
                                echo "<label>{$field['label']}</label>";
                                echo "<input type='{$field['type']}' name='{$field['name']}' class='form-control'" . 
                                    (isset($field['placeholder']) ? " placeholder='{$field['placeholder']}'" : "") .
                                    (isset($field['min']) ? " min='{$field['min']}'" : "") .
                                    ($field['required'] ? " required" : "") . ">";
                                echo "</div>";
                            }
                            ?>
                            <div class="form-group">
                                <label>Attachment (optional)</label>
                                <input type="file" name="file_attachment" class="form-control-file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                            </div>
                        </div>

                        <!-- Right Column -->
                        <div class="col-md-6">
                            <?php
                            $rightFields = [
                                ['label' => 'Agenda Summary', 'name' => 'agenda_summary'],
                                ['label' => 'Agenda 1', 'name' => 'agenda_1'],
                                ['label' => 'Agenda 2', 'name' => 'agenda_2'],
                                ['label' => 'Agenda 3', 'name' => 'agenda_3'],
                                ['label' => 'Agenda 4', 'name' => 'agenda_4'],
                                ['label' => 'Other Matters', 'name' => 'other_matters'],
                            ];
                            foreach ($rightFields as $field) {
                                echo "<div class='form-group'>";
                                echo "<label>{$field['label']}</label>";
                                echo "<textarea name='{$field['name']}' class='form-control' rows='2'></textarea>";
                                echo "</div>";
                            }
                            ?>
                            <div class="form-group">
                                <label>Adjournment Details</label>
                                <input type="text" name="adjournment" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" class="btn btn-success">Save</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Table -->
<div class="container px-2.5">
    <div class="card shadow mb-4">
        <div class="card-header py-3 bg-info text-white">
            <h6 class="m-0 font-weight-bold">Minutes of Meetings</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover" id="minutesTable">
                    <thead class="thead-light">
                        <tr>
                            <th>ID</th>
                            <th>Meeting Type</th>
                            <th>Date & Time</th>
                            <th>Attachment</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM tbl_mom WHERE archived = 0 ORDER BY meeting_datetime DESC";
                        $result = $conn->query($query);
                        while ($row = $result->fetch_assoc()) {
                            $data_json = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
                            $formatted_date = date("M d, Y h:i A", strtotime($row['meeting_datetime']));
                            $file = $row['attachment'] 
                                ? "<a href='uploads/{$row['attachment']}' class='badge badge-success' target='_blank'><i class='fas fa-file-alt'></i> View</a>" 
                                : "<span class='text-muted'>None</span>";

                            echo "<tr data-minutes='{$data_json}'>
                                <td>{$row['mom_id']}</td>
                                <td>" . htmlspecialchars($row['meeting_type']) . "</td>
                                <td>{$formatted_date}</td>
                                <td>{$file}</td>
                                <td>
                                <button class='btn btn-info btn-sm view-details'><i class='fas fa-eye'></i></button>
                                <button class='btn btn-danger btn-sm archive-btn' data-id='{$row['mom_id']}'><i class='fas fa-archive'></i></button>
                                </td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- See More Modal -->
<div class="modal fade" id="seeMoreModal" tabindex="-1" role="dialog" aria-labelledby="seeMoreModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title" id="seeMoreModalLabel">Minutes Details</h5>
                <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" id="modalContent"></div>
        </div>
    </div>
</div>
>

<script>
    // JavaScript for viewing details in modal (optional based on your logic)
    document.querySelectorAll('.view-details').forEach(button => {
        button.addEventListener('click', function () {
            const row = this.closest('tr');
            const data = JSON.parse(row.getAttribute('data-minutes'));
            let html = `<strong>Meeting Type:</strong> ${data.meeting_type}<br>
                        <strong>Date & Time:</strong> ${new Date(data.meeting_datetime).toLocaleString()}<br>
                        <strong>Location:</strong> ${data.location}<br>
                        <strong>Presiding Officer:</strong> ${data.presiding_officer}<br>
                        <strong>Secretary:</strong> ${data.secretary}<br>
                        <strong>No. of Attendees:</strong> ${data.present_count}<br>
                        <strong>Agenda Summary:</strong> ${data.agenda_summary}<br>
                        <strong>Agenda 1:</strong> ${data.agenda_1}<br>
                        <strong>Agenda 2:</strong> ${data.agenda_2}<br>
                        <strong>Agenda 3:</strong> ${data.agenda_3}<br>
                        <strong>Agenda 4:</strong> ${data.agenda_4}<br>
                        <strong>Other Matters:</strong> ${data.other_matters}<br>
                        <strong>Adjournment:</strong> ${data.adjournment}`;
            document.getElementById('modalContent').innerHTML = html;
            $('#seeMoreModal').modal('show');
        });
    });
</script>

<script>
document.querySelectorAll('.archive-btn').forEach(button => {
    button.addEventListener('click', function () {
        const momId = this.getAttribute('data-id');
        if (confirm('Are you sure you want to archive this record?')) {
            fetch('MOM_archive.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'archive_id=' + momId
            })
            .then(response => response.text())
            .then(data => {
                alert('Archived successfully!');
                location.reload();
            })
            .catch(error => {
                alert('Failed to archive.');
                console.error(error);
            });
        }
    });
});
</script>
