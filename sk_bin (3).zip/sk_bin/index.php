<?php
session_start();
$message = "";
$view = $_GET['view'] ?? 'login';

// Connect to database
$pdo = new PDO("mysql:host=localhost;dbname=sk_bin", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit();
}

// Register
if (isset($_POST['register'])) {
    $username = htmlspecialchars(trim($_POST["reg_username"]));
    $password = htmlspecialchars(trim($_POST["reg_password"]));
    $view = 'register';

    if ($username && $password) {
        $stmt = $pdo->prepare("SELECT * FROM user WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->fetch()) {
            $message = "<div class='alert'>Username already exists.</div>";
        } else {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $insert = $pdo->prepare("INSERT INTO user (username, password) VALUES (?, ?)");
            $insert->execute([$username, $hashed]);
            $message = "<div class='success'>Registration successful. Please log in.</div>";
            $view = 'login';
        }
    } else {
        $message = "<div class='alert'>Please fill in all fields.</div>";
    }
}

// Login
if (isset($_POST['login'])) {
    $username = htmlspecialchars(trim($_POST["log_username"]));
    $password = trim($_POST["log_password"]);

    $stmt = $pdo->prepare("SELECT * FROM staff WHERE username = ?");
    $stmt->execute([$username]);
    $staff = $stmt->fetch();

    if ($staff && password_verify($password, $staff['password'])) {
        $_SESSION["username"] = $username;
        header("Location: dashboard.php");
        exit();
    } else {
        $message = "<div class='alert'>Invalid login credentials.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            background: linear-gradient(to right, #667eea, #764ba2);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }
        .card {
            background: #fff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            font-weight: 600;
            color: #333;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        .btn {
            width: 100%;
            padding: 0.75rem;
            background: #667eea;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #5a67d8;
        }
        .text-center {
            text-align: center;
            margin-top: 1rem;
        }
        .text-center a {
            color: #667eea;
            text-decoration: none;
        }
        .text-center a:hover {
            text-decoration: underline;
        }
        .alert {
            background-color: #ffdddd;
            color: #a94442;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
        .success {
            background-color: #ddffdd;
            color: #3c763d;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

<div class="card">
    <?php if (isset($_SESSION["username"])): ?>
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION["username"]); ?>!</h2>
        <p class="text-center"><a href="?logout=true" class="btn">Logout</a></p>
    <?php else: ?>
        <?php echo $message; ?>

        <?php if ($view === 'register'): ?>
            <h2>Create Account</h2>
            <form method="post">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="reg_username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="reg_password" class="form-control" required>
                </div>
                <button type="submit" name="register" class="btn">Register</button>
            </form>
            <p class="text-center">Already have an account? <a href="index.php?view=login">Login here</a></p>

        <?php else: ?>
            <h2>Login</h2>
            <form method="post">
                <div class="form-group">
                    <label>Username</label>
                    <input type="text" name="log_username" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="log_password" class="form-control" required>
                </div>
                <button type="submit" name="login" class="btn">Login</button>
            </form>
            <p class="text-center">Don't have an account? <a href="registration.php?view=register">Register here</a></p>
        <?php endif; ?>
    <?php endif; ?>
</div>

</body>
</html>
