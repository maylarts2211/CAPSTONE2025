<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>

<div class="container mt-5">
    <h4 class="mb-4">Youth Complaints</h4>
    <div class="row">

        <!-- Complaint Card 1 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow border-left-danger h-100 complaint-card">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title font-weight-bold text-dark">Juan Dela Cruz</h5>
                    <p class="card-text text-muted mb-3">Barangay: <strong>Bangga</strong></p>
                    <p class="card-text text-muted mb-3" style="flex-grow:1;">
                        The basketball court lights are broken. We can’t play in the evening anymore.
                    </p>
                    <!-- Button linking to complaint_done.php -->
                    <a href="complaint_done.php" class="btn btn-outline-success btn-sm w-100 mark-done-btn">Mark as Done</a>
                </div>
            </div>
        </div>

        <!-- Complaint Card 2 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow border-left-danger h-100 complaint-card">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title font-weight-bold text-dark">Maria Santos</h5>
                    <p class="card-text text-muted mb-3">Barangay: <strong>Bantayan</strong></p>
                    <p class="card-text text-muted mb-3" style="flex-grow:1;">
                        I hope the SK can organize more youth seminars on leadership and mental health.
                    </p>
                    <!-- Button linking to complaint_done.php -->
                    <a href="complaint_done.php" class="btn btn-outline-success btn-sm w-100 mark-done-btn">Mark as Done</a>
                </div>
            </div>
        </div>

        <!-- Complaint Card 3 -->
        <div class="col-md-4 mb-4">
            <div class="card shadow border-left-danger h-100 complaint-card">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title font-weight-bold text-dark">Paolo Rivera</h5>
                    <p class="card-text text-muted mb-3">Barangay: <strong>Poblacion</strong></p>
                    <p class="card-text text-muted mb-3" style="flex-grow:1;">
                        There’s too much trash in the waiting area near the barangay hall. Please provide bins.
                    </p>
                    <!-- Button linking to complaint_done.php -->
                    <a href="complaint_done.php" class="btn btn-outline-success btn-sm w-100 mark-done-btn">Mark as Done</a>
                </div>
            </div>
        </div>

    </div>
</div>

<?php
include('includes/footer.php');
?>

<!-- Add the CSS styles -->
<style>
    .complaint-card {
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .complaint-card:hover {
        transform: translateY(-10px);
        box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.15);
    }

    .mark-done-btn {
        transition: background-color 0.3s ease, color 0.3s ease;
    }

    .mark-done-btn:hover {
        background-color: #28a745;
        color: white;
    }
</style>
