<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
?>

<div class="container-fluid mt-4">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><i class="fas fa-tasks"></i> Task Manager</h1>
    <p class="mb-4">Assign and monitor tasks per barangay, committee, or individual officer.</p>

    <!-- Create New Task Card -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary"><i class="fas fa-plus-circle"></i> Create New Task</h6>
        </div>
        <div class="card-body">
            <form action="submit_task.php" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="taskTitle"><i class="fas fa-heading"></i> Task Title</label>
                    <input type="text" class="form-control" id="taskTitle" name="taskTitle" required placeholder="Enter task title">
                </div>

                <div class="form-group">
                    <label for="taskDescription"><i class="fas fa-align-left"></i> Description / Instructions</label>
                    <textarea class="form-control" id="taskDescription" name="taskDescription" rows="4" required placeholder="Provide task details or instructions"></textarea>
                </div>

                

                <div class="form-group">
                    <label for="category"><i class="fas fa-folder"></i> Task Category</label>
                    <select class="form-control" id="category" name="category" required>
                        <option value="Event">Event</option>
                        <option value="Report">Report</option>
                        <option value="Budget">Budget</option>
                        <option value="Outreach">Outreach</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="dueDate"><i class="fas fa-calendar-alt"></i> Deadline / Due Date</label>
                    <input type="date" class="form-control" id="dueDate" name="dueDate" required>
                </div>

                <div class="form-group">
                    <label for="fileAttachment"><i class="fas fa-paperclip"></i> File Attachment (optional)</label>
                    <input type="file" class="form-control-file" id="fileAttachment" name="fileAttachment">
                </div>

                <div class="form-group">
                    <label for="assignedTo"><i class="fas fa-users-cog"></i> Assigned To</label>
                    <select class="form-control" id="assignedTo" name="assignedTo" required>
                        <optgroup label="Barangay SK Councils">
                            <option value="Barangay 1">Barangay 1</option>
                            <option value="Barangay 2">Barangay 2</option>
                            <!-- Add more barangays -->
                        </optgroup>
                        <optgroup label="Committee Heads">
                            <option value="Sports Committee">Sports Committee</option>
                            <option value="Environment Committee">Environment Committee</option>
                        </optgroup>
                        <optgroup label="Individual Officers">
                            <option value="Secretary">Secretary</option>
                            <option value="Treasurer">Treasurer</option>
                        </optgroup>
                    </select>
                </div>

                <button type="submit" class="btn btn-primary btn-block"><i class="fas fa-paper-plane"></i> Assign Task</button>
            </form>
        </div>
    </div>

</div>

<?php
include('includes/footer.php');
?>
