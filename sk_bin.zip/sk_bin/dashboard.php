<?php
include('../includes/header.php');
include('../includes/navbar.php');
include('../includes/topbar.php');
?>



<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
    <a href="#" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
      <i class="fas fa-download fa-sm text-white-50"></i> Generate Report
    </a>
  </div>

  <!-- Stats Summary Cards -->
  <div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Barangay</div>
          <div class="h5 mb-0 font-weight-bold text-gray-800">20</div>
        </div>
      </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
          <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Youth Registered</div>
          <div class="h5 mb-0 font-weight-bold text-gray-800">150</div>
        </div>
      </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-warning shadow h-100 py-2">
        <div class="card-body">
          <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pending Youth Feedback</div>
          <div class="h5 mb-0 font-weight-bold text-gray-800">12</div>
        </div>
      </div>
    </div>
    
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-info shadow h-100 py-2">
        <div class="card-body">
          <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Incoming Events</div>
          <div class="h5 mb-0 font-weight-bold text-gray-800">5</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Main Features Section -->
  <div class="row">
    <div class="col-md-4 mb-4">
      <a href="planning_budgeting.php" class="text-decoration-none">
        <div class="card shadow h-100">
          <div class="card-body text-center">
            <i class="fas fa-file-invoice-dollar fa-3x text-primary mb-3"></i>
            <h5 class="card-title">Planning and Budgeting</h5>
            <p class="card-text text-muted">Manage plans and budgets</p>
          </div>
        </div>
      </a>
    </div>
    
    <div class="col-md-4 mb-4">
      <a href="youth_id.php" class="text-decoration-none">
        <div class="card shadow h-100">
          <div class="card-body text-center">
            <i class="fas fa-id-card fa-3x text-success mb-3"></i>
            <h5 class="card-title">Youth ID</h5>
            <p class="card-text text-muted">Manage youth identification</p>
          </div>
        </div>
      </a>
    </div>
    
    <div class="col-md-4 mb-4">
      <a href="youth_feedback.php" class="text-decoration-none">
        <div class="card shadow h-100">
          <div class="card-body text-center">
            <i class="fas fa-comments fa-3x text-warning mb-3"></i>
            <h5 class="card-title">Youth Feedback</h5>
            <p class="card-text text-muted">Review youth feedbacks</p>
          </div>
        </div>
      </a>
    </div>
    
    <div class="col-md-6 mb-4">
      <a href="document_management.php" class="text-decoration-none">
        <div class="card shadow h-100">
          <div class="card-body text-center">
            <i class="fas fa-folder-open fa-3x text-info mb-3"></i>
            <h5 class="card-title">Document Management</h5>
            <p class="card-text text-muted">Manage documents and files</p>
          </div>
        </div>
      </a>
    </div>
    
    <div class="col-md-6 mb-4">
      <a href="financial_management.php" class="text-decoration-none">
        <div class="card shadow h-100">
          <div class="card-body text-center">
            <i class="fas fa-money-bill-wave fa-3x text-danger mb-3"></i>
            <h5 class="card-title">Financial Management</h5>
            <p class="card-text text-muted">Track finances and transactions</p>
          </div>
        </div>
      </a>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

<?php
 include('includes/scripts.php');
 include('includes/footer.php');
?>
