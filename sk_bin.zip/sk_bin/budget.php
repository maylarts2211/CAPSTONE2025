<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SK Federation Budget</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
      background-image: linear-gradient(to right, #7f8c8d, #34495e);
    }
    .card {
      background-color: #ffffff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
      width: 350px;
      text-align: center;
      margin: 30px auto;
    }
    h1 {
      color: #1b4332;
      font-size: 24px;
    }
    .budget-info {
      margin-top: 20px;
    }
    .budget-info p {
      font-size: 18px;
      margin: 10px 0;
    }
    .budget-info input {
      padding: 10px;
      width: 100%;
      margin-top: 10px;
      margin-bottom: 10px;
      border: 1px solid #aaa;
      border-radius: 4px;
      font-size: 16px;
    }
    .budget-info button {
      background-color: #2d6a4f;
      color: white;
      padding: 12px 20px;
      border: none;
      cursor: pointer;
      border-radius: 5px;
      font-size: 16px;
      width: 100%;
      margin-top: 10px;
    }
    .budget-info button:hover {
      background-color: #1b4332;
    }
    .budget-info p strong {
      font-size: 18px;
    }
  </style>
</head>
<body>

  <div class="card">
    <h1>SK Federation Budget Report</h1>

    <div class="budget-info">
      <label for="barangayBudget"><strong>Enter Barangay Annual Budget (₱):</strong></label>
      <input type="number" id="barangayBudget" placeholder="e.g. 1000000">

      <button onclick="calculateSKBudget()">Calculate SK Federation Budget (10%)</button>

      <p id="skResult"><strong>SK Federation Budget:</strong> ₱0.00</p>
    </div>
  </div>

  <!-- You can add additional content below this card as needed -->

  <script>
    function calculateSKBudget() {
      const barangayBudget = parseFloat(document.getElementById('barangayBudget').value);
      const resultEl = document.getElementById('skResult');
      
      if (!isNaN(barangayBudget) && barangayBudget > 0) {
        const skBudget = barangayBudget * 0.10;
        resultEl.innerHTML = `<strong>SK Federation Budget:</strong> ₱${skBudget.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
      } else {
        resultEl.innerHTML = `<strong>Please enter a valid Barangay Budget.</strong>`;
      }
    }
  </script>

</body>
</html>
