<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sample: you should verify against your database here
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Example check, replace with your DB logic
    if ($username === 'admin' && $password === 'password123') {
        $_SESSION['user_id'] = 1;  // or any unique user identifier
        $_SESSION['username'] = $username;
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid username or password.";
    }
}
?>

<form method="post" action="login.php">
    <input type="text" name="username" required placeholder="Username" />
    <input type="password" name="password" required placeholder="Password" />
    <button type="submit">Login</button>
</form>

<?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
