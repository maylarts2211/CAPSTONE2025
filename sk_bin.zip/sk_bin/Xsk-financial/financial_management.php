<?php
include('../includes/header.php');
include('../includes/navbar.php');
include('../includes/topbar.php');

// Get the current page filename (e.g., 'liquidation_report.php')
$currentPage = basename($_SERVER['PHP_SELF']);
?>

<div class="container-fluid mt-4">

  <div class="card-body py-1 px-0 border-bottom d-flex justify-content-between align-items-center flex-wrap">
    <div class="d-flex gap-1 flex-wrap align-items-center">

      <a href="liquidation_report.php" class="btn btn-sm <?php echo ($currentPage == 'liquidation_report.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2">
        Liquidation Report
      </a>


      <a href="financial_report.php" class="btn btn-sm <?php echo ($currentPage == 'financial_report.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2">
        Financial Report
      </a>

    </div>
  </div>

</div>
