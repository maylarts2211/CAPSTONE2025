<?php
// Direct database connection (no include)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sk_bin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $barangay_name = trim($_POST['barangay_name']);

    if (!empty($barangay_name)) {
        // Prepare and execute SQL statement
        $stmt = $conn->prepare("INSERT INTO barangay (brgy_name, created_at) VALUES (?, NOW())");
        $stmt->bind_param("s", $barangay_name);

        if ($stmt->execute()) {
            // Redirect on success
            header("Location: process_add_brgy.php?success=1");
            exit();
        } else {
            echo "Error inserting data: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Barangay name is required.";
    }
}

$conn->close();
?>
