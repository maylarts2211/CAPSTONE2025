<?php
// Connection to database
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "sk_bin"; // <-- Palitan ng actual DB name

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch officer info
$sql = "SELECT * FROM brgy_amontay WHERE id = $id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $officer = $result->fetch_assoc();
} else {
    die("Officer not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Youth Resume Profile - Display Only</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f8f9fc;
      margin: 0;
      padding: 20px;
    }
    .profile-container {
      max-width: 900px;
      margin: 30px auto;
      background: white;
      border-radius: 10px;
      box-shadow: 0 0 12px rgba(0,0,0,0.12);
      padding: 30px 40px;
      box-sizing: border-box;
      display: flex;
      gap: 40px;
      font-size: 15px;
    }
    .photo-box {
      flex: 0 0 250px;
      border: 2px dashed #ced4da;
      border-radius: 10px;
      height: 300px;
      background: #e9ecef;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      flex-direction: column;
      position: relative;
    }
    .photo-box img.profile-photo {
      max-width: 100%;
      max-height: 100%;
      object-fit: cover;
      border-radius: 10px;
    }
    .profile-details {
      flex: 1;
    }
    .profile-details h2 {
      margin-top: 0;
      margin-bottom: 5px;
      color: #4e73df;
      font-weight: 700;
    }
    .profile-details h4 {
      margin-bottom: 10px;
      border-bottom: 2px solid #4e73df;
      padding-bottom: 4px;
      color: #4e73df;
    }
    .info-row {
      margin-bottom: 12px;
    }
    .info-label {
      font-weight: 700;
      color: #343a40;
      width: 140px;
      display: inline-block;
    }
    .print-button {
      display: block;
      margin: 30px auto;
      padding: 10px 20px;
      background: #4e73df;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
    }
    .id-header {
      display: none;
      flex-direction: column;
      align-items: center;
      text-align: center;
      padding-bottom: 10px;
    }
    .id-header img {
      width: 60px;
      height: 60px;
      object-fit: contain;
      margin-bottom: 5px;
    }
    .id-header h2 {
      font-size: 16px;
      margin: 0;
      font-weight: bold;
    }
    .id-header p {
      font-size: 12px;
      margin: 2px 0 5px;
    }
    @media (max-width: 768px) {
      .profile-container {
        flex-direction: column;
      }
      .photo-box {
        width: 100%;
        height: auto;
      }
    }
    @media print {
      body {
        background: white;
        margin: 0;
        padding: 0;
      }
      .print-button,
      .profile-details h4,
      .info-row:not(.print-only) {
        display: none !important;
      }
      .profile-container {
        display: block;
        width: 300px;
        border: 2px solid #000;
        padding: 10px;
        box-shadow: none;
        text-align: center;
      }
      .id-header {
        display: flex !important;
      }
      .photo-box {
        height: auto;
        border: none;
        margin-bottom: 10px;
      }
      .photo-box img.profile-photo {
        max-height: 250px;
      }
      .profile-details {
        display: block;
        margin-top: 10px;
      }
      .info-row.print-only {
        display: block !important;
        font-size: 14px;
        margin-bottom: 8px;
      }
    }
  </style>
</head>
<body>

<div class="profile-container">
  <div class="photo-box">
    <div class="id-header">
      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/33/Philippine_Youth_Development_Plan.png/600px-Philippine_Youth_Development_Plan.png" alt="Org Logo" />
      <h2>YOUTH ORGANIZATION OF BARANGAY MABINI</h2>
      <p>Purok Paglaum, Barangay Mabini, Binalbagan, Negros Occidental</p>
    </div>

    <img class="profile-photo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJv28G_0oK1p-CKBX8J_AZAOZBRmCpGjP-6w&s" alt="Profile Photo" />
  </div>

  <div class="profile-details">
    <h2><?= htmlspecialchars($officer['full_name'] ?? '') ?></h2>
    <h4>Youth Resume Profile</h4>


    <div class="info-row print-only"><span class="info-label">Position:</span> Youth Officer</div>
    <div class="info-row print-only"><span class="info-label">Barangay:</span> <?= htmlspecialchars($officer['address'] ?? 'N/A') ?></div>

    <div class="info-row"><span class="info-label">Age:</span> <?= htmlspecialchars($officer['age'] ?? 'N/A') ?></div>
    <div class="info-row"><span class="info-label">Sex:</span> <?= htmlspecialchars($officer['gender'] ?? 'N/A') ?></div>
    <div class="info-row"><span class="info-label">Contact:</span> <?= htmlspecialchars($officer['contact'] ?? 'N/A') ?></div>
    <div class="info-row"><span class="info-label">Email:</span> <?= htmlspecialchars($officer['email'] ?? 'N/A') ?></div>
    <div class="info-row"><span class="info-label">Education:</span> <?= htmlspecialchars($officer['education'] ?? 'N/A') ?></div>
    <div class="info-row"><span class="info-label">Term:</span> <?= htmlspecialchars($officer['term_start'] ?? '') ?> - <?= htmlspecialchars($officer['term_end'] ?? '') ?></div>
    <div class="info-row"><span class="info-label">Created At:</span> <?= htmlspecialchars($officer['created_at'] ?? '') ?></div>
  </div>
</div>

<button class="print-button" onclick="window.print()">Print</button>

</body>
</html>
