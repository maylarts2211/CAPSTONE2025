<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>

<div class="container-fluid mt-4">

    <!-- Page Heading -->
  

    <div class="card-body py-1 px-0 border-bottom d-flex justify-content-between align-items-center flex-wrap">

  <!-- Left: Navigation Links -->
  <div class="d-flex gap-1 flex-wrap align-items-center">
    <a href="m_CBYDP.php" class="btn btn-sm btn-primary fw-semibold rounded-pill px-4 py-2 shadow-sm">
      CBYDP
    </a>
    <a href="m_ABYIP.php" class="btn btn-sm btn-outline-primary rounded-pill px-4 py-2">
      ABYIP
    </a>
    
  </div>

</div>


<?php
include('includes/footer.php');
?>
