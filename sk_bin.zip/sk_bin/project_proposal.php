<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>


<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Project Proposal Management</h1>
 
<!-- Add Proposal Button -->
<div class="mb-3 d-flex justify-content-between">
    <a href="add_new_proposal.php" class="btn btn-primary btn-sm">
        <i class="fas fa-plus-circle"></i> Add Proposal
    </a>
</div>

    <!-- Proposal Table -->
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Project Proposals</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="proposalTable" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Project Title</th>
                            <th>Date Implemented</th>
                            <th>Barangay</th>
                            <th>Total Budget</th>
                            <th>Youth Benefited</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="proposalList">
                        <tr>
                            <td>1</td>
                            <td>Clean-Up Drive</td>
                            <td>2025-05-10</td>
                            <td>Brgy. Uno</td>
                            <td>₱3,000.00</td>
                            <td>40</td>
                            <td><span class="badge badge-warning">Pending</span></td>
                            <td>
                                <button class="btn btn-sm btn-success" onclick="updateStatus(this, 'Accepted')">Accept</button>
                                <button class="btn btn-sm btn-danger" onclick="updateStatus(this, 'Declined')">Decline</button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <!-- Bottom Controls -->
            <div class="d-flex justify-content-between mt-3">
                <button onclick="printTable()" class="btn btn-primary btn-sm"><i class="fas fa-print"></i> Print</button>
                <div></div>
            </div>
        </div>
    </div>
</div>

<!-- Scripts -->
<script>
    let proposalCounter = 2;

    function submitProposal() {
        const barangay = $('#barangay_name').val();
        const title = $('#proposal_title').val();
        const desc = $('#proposal_description').val();
        const budget = $('#proposal_budget').val();
        const date = $('#proposal_date').val();
        const benefit = $('#proposal_benefit').val();

        if (!barangay || !title || !desc || !budget || !date || !benefit) {
            alert("Please fill out all fields.");
            return;
        }

        const newRow = `
            <tr>
                <td>${proposalCounter}</td>
                <td>${title}</td>
                <td>${date}</td>
                <td>${barangay}</td>
                <td>₱${parseFloat(budget).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                <td>${benefit}</td>
                <td><span class="badge badge-warning">Pending</span></td>
                <td>
                    <button class="btn btn-sm btn-success" onclick="updateStatus(this, 'Accepted')">Accept</button>
                    <button class="btn btn-sm btn-danger" onclick="updateStatus(this, 'Declined')">Decline</button>
                </td>
            </tr>
        `;
        $('#proposalList').append(newRow);
        proposalCounter++;

        $('#proposalForm')[0].reset();
        $('#proposalTable').DataTable().destroy();
        $('#proposalTable').DataTable(); // Refresh DataTable
    }

    function updateStatus(button, status) {
        const row = $(button).closest('tr');
        let badgeClass = 'badge-secondary';

        if (status === 'Accepted') badgeClass = 'badge-success';
        if (status === 'Declined') badgeClass = 'badge-danger';

        row.find('td:eq(6)').html(`<span class="badge ${badgeClass}">${status}</span>`);
    }

    function printTable() {
        const printContents = document.getElementById('proposalTable').outerHTML;
        const printWindow = window.open('', '', 'height=600,width=1000');
        printWindow.document.write('<html><head><title>Project Proposals</title>');
        printWindow.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">');
        printWindow.document.write('</head><body>');
        printWindow.document.write('<h2 class="text-center my-4">SK Project Proposals</h2>');
        printWindow.document.write(printContents);
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        printWindow.print();
    }

    $(document).ready(function () {
        $('#proposalTable').DataTable();
    });
</script>


<?php include('includes/footer.php'); ?>
