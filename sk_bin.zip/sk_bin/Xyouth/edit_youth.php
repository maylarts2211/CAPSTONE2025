<?php
include('../includes/connect.php');
session_start();

if (!isset($_GET['id'])) {
    die("No ID provided.");
}

$id = (int)$_GET['id'];

// Fetch youth info
$sql = "SELECT * FROM tbl_youth WHERE youth_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Youth not found.");
}

$youth = $result->fetch_assoc();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $contact = $_POST['contact_number'];
    $email = $_POST['email'];
    $address = $_POST['address'];

    // Handle file upload
    $profilePicName = $youth['profile_picture'];
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === 0) {
        $uploadDir = "uploads/youth_pics/";
        $profilePicName = time() . "_" . basename($_FILES["profile_picture"]["name"]);
        move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $uploadDir . $profilePicName);
    }

    // Update record
    $update = "UPDATE tbl_youth SET full_name=?, contact_number=?, email=?, address=?, profile_picture=? WHERE youth_id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("sssssi", $full_name, $contact, $email, $address, $profilePicName, $id);

    if ($stmt->execute()) {
        header("Location: youthProfile.php?id=" . $id);
        exit;
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Youth</title>
  <?php include('../includes/header.php'); ?>
</head>
<body>
<?php include('../includes/navbar.php'); include('../includes/topbar.php'); ?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">

      <div class="card card-primary">
        <div class="card-header"><h3 class="card-title">Edit Youth Information</h3></div>
        <form method="POST" enctype="multipart/form-data">
          <div class="card-body">
            <div class="form-group">
              <label>Full Name</label>
              <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($youth['full_name']) ?>" required>
            </div>

            <div class="form-group">
              <label>Contact Number</label>
              <input type="text" name="contact_number" class="form-control" value="<?= htmlspecialchars($youth['contact_number']) ?>" required>
            </div>

            <div class="form-group">
              <label>Email</label>
              <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($youth['email']) ?>">
            </div>

            <div class="form-group">
              <label>Address</label>
              <textarea name="address" class="form-control" required><?= htmlspecialchars($youth['address']) ?></textarea>
            </div>

            <div class="form-group">
              <label>Current Profile Picture</label><br>
              <?php
              $defaultPic = "assets/default-profile.png";
              $profilePicPath = (!empty($youth['profile_picture']) && file_exists("uploads/youth_pics/" . $youth['profile_picture']))
                  ? "uploads/youth_pics/" . $youth['profile_picture']
                  : $defaultPic;
              ?>
              <img src="<?= htmlspecialchars($profilePicPath) ?>" alt="Current Picture" width="100" class="img-thumbnail mb-2"><br>

              <label>Change Picture</label>
              <input type="file" name="profile_picture" class="form-control">
            </div>
          </div>

          <div class="card-footer">
            <button type="submit" class="btn btn-success">Save Changes</button>
            <a href="youth.php" class="btn btn-secondary">Cancel</a>
          </div>
        </form>
      </div>

    </div>
  </section>
</div>

<?php include('../includes/footer.php'); ?>
</body>
</html>
