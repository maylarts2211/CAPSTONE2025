<?php
include('../includes/connect.php');
session_start();

if (!isset($_GET['id'])) {
    die('No ID provided.');
}

$id = (int)$_GET['id'];

$sql = "SELECT * FROM tbl_youth WHERE youth_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Youth not found.");
}

$youth = $result->fetch_assoc();

$defaultPic = "assets/default-profile.png"; 
$profilePic = !empty($youth['profile_picture']) && file_exists("uploads/youth_pics/" . $youth['profile_picture'])
    ? "uploads/youth_pics/" . $youth['profile_picture']
    : $defaultPic;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Youth Profile - ID Card</title>
  <?php include('../includes/header.php'); ?>
  <style>
    .id-card {
      width: 320px;
      border: 2px solid #007bff;
      border-radius: 12px;
      padding: 20px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      background: #f9f9f9;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 30px auto;
      text-align: center;
    }

    .id-card img {
      width: 160px;
      height: 160px;
      border-radius: 50%;
      object-fit: cover;
      border: 3px solid #007bff;
      margin-bottom: 15px;
    }

    .id-card h2 {
      margin: 0;
      font-size: 24px;
      color: #003366;
      font-weight: 700;
    }

    .id-card p {
      margin: 6px 0;
      font-size: 16px;
      color: #333;
    }

    .back-btn {
      display: block;
      width: 140px;
      margin: 20px auto 0;
    }
  </style>
</head>
<body>
<?php
include('../includes/navbar.php');
include('../includes/topbar.php');
?>

<div class="content-wrapper">
  <section class="content">
    <div class="container-fluid">

      <div class="id-card">
        <img src="<?= htmlspecialchars($profilePic) ?>" alt="Profile Picture" />
        <h2><?= htmlspecialchars($youth['full_name']) ?></h2>
        <p><strong>Contact:</strong> <?= htmlspecialchars($youth['contact_number']) ?></p>
        <p><strong>Email:</strong> <?= htmlspecialchars($youth['email']) ?></p>
        <p><strong>Address:</strong> <?= htmlspecialchars($youth['address']) ?></p>
      </div>

 <a href="youth.php" class="btn btn-primary back-btn">
  <i class="fas fa-arrow-left"></i> Back
</a>


    </div>
  </section>
</div>


</body>
</html>
