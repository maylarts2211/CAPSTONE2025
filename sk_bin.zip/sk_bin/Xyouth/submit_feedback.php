<?php
header('Content-Type: application/json');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sk_bin";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'DB Connection failed']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $gmail = $conn->real_escape_string($_POST['gmail'] ?? '');
    $full_name = $conn->real_escape_string($_POST['full_name'] ?? '');
    $barangay_id = (int)($_POST['barangay'] ?? 0);
    $category = $conn->real_escape_string($_POST['category'] ?? '');
    $message = $conn->real_escape_string($_POST['message'] ?? '');

    if (!$gmail || !$full_name || !$barangay_id || !$category || !$message) {
        echo json_encode(['success' => false, 'message' => 'All fields are required.']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO sk_feedback (gmail, full_name, barangay_id, category, message, date_submitted) VALUES (?, ?, ?, ?, ?, NOW())");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Prepare failed: ' . $conn->error]);
        exit;
    }

    $stmt->bind_param("ssiss", $gmail, $full_name, $barangay_id, $category, $message);
    if ($stmt->execute()) {
        $feedbacks = [];
        $sql = "SELECT f.gmail, f.full_name, b.brgy_name, f.category, f.message, DATE_FORMAT(f.date_submitted, '%Y-%m-%d %H:%i:%s') as submitted_at
                FROM sk_feedback f
                LEFT JOIN barangay b ON f.barangay_id = b.id
                ORDER BY f.date_submitted DESC LIMIT 10";
        $res = $conn->query($sql);
        if ($res && $res->num_rows > 0) {
            while ($row = $res->fetch_assoc()) {
                $feedbacks[] = $row;
            }
        }
        echo json_encode(['success' => true, 'feedbacks' => $feedbacks]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to submit feedback.']);
    }

    $stmt->close();
    $conn->close();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET' && ($_GET['action'] ?? '') === 'fetch') {
    $feedbacks = [];
    $sql = "SELECT f.gmail, f.full_name, b.brgy_name, f.category, f.message, DATE_FORMAT(f.date_submitted, '%Y-%m-%d %H:%i:%s') as submitted_at
            FROM sk_feedback f
            LEFT JOIN barangay b ON f.barangay_id = b.id
            ORDER BY f.date_submitted DESC LIMIT 10";
    $res = $conn->query($sql);
    if ($res && $res->num_rows > 0) {
        while ($row = $res->fetch_assoc()) {
            $feedbacks[] = $row;
        }
    }
    echo json_encode(['success' => true, 'feedbacks' => $feedbacks]);
    $conn->close();
    exit;
}

echo json_encode(['success' => false, 'message' => 'Invalid request']);
$conn->close();
exit;
?>
