<?php
// Database connection
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'sk_bin';

$config = new mysqli($host, $user, $pass, $dbname);
if ($config->connect_error) {
    die("Connection failed: " . $config->connect_error);
}

// Response para sa message
$response = ['success' => false, 'message' => ''];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'] ?? '';
    $gender = $_POST['gender'] ?? '';
    $email = $_POST['email'] ?? '';
    $contact_number = $_POST['contact_number'] ?? '';
    $date_of_birth = $_POST['date_of_birth'] ?? '';
    $address = $_POST['address'] ?? '';
    $profile_picture = '';

    // File upload handling
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === 0) {
        $uploadDir = "uploads/youth_pics/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // create folder if it doesn't exist
        }

        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'image/gif'];
        $fileType = mime_content_type($_FILES['profile_picture']['tmp_name']);

        if (in_array($fileType, $allowedTypes)) {
            $fileName = time() . "_" . basename($_FILES["profile_picture"]["name"]);
            $targetPath = $uploadDir . $fileName;

            if (move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $targetPath)) {
                $profile_picture = $fileName;
            } else {
                $response['message'] = 'Failed to move uploaded file.';
            }
        } else {
            $response['message'] = 'Invalid file type. Only images allowed.';
        }
    }

    if (empty($response['message'])) {
        if (empty($full_name) || empty($gender) || empty($email) || empty($contact_number) || empty($date_of_birth) || empty($address)) {
            $response['message'] = 'Paki-fill lahat ng required fields.';
        } else {
            $sql = "INSERT INTO tbl_youth (full_name, gender, email, contact_number, date_of_birth, address, profile_picture)
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmt = $config->prepare($sql);
            if ($stmt === false) {
                $response['message'] = 'Prepare failed: ' . htmlspecialchars($config->error);
            } else {
                $stmt->bind_param("sssssss", $full_name, $gender, $email, $contact_number, $date_of_birth, $address, $profile_picture);
                if ($stmt->execute()) {
                    $response['success'] = true;
                    $response['message'] = 'Youth member added successfully!';
                } else {
                    $response['message'] = 'Error: ' . htmlspecialchars($stmt->error);
                }
                $stmt->close();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Add Youth Member</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>

<div class="container py-4">
  <h2>Add Youth Member</h2>

  <?php if ($response['success']): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      <strong>Success!</strong> <?= $response['message']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php elseif (!empty($response['message'])): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error!</strong> <?= $response['message']; ?>
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  <?php endif; ?>

  <form method="post" action="" enctype="multipart/form-data">
    <div class="mb-3">
      <label for="full_name" class="form-label">Full Name</label>
      <input type="text" class="form-control" name="full_name" id="full_name" required />
    </div>

    <div class="mb-3">
      <label for="date_of_birth" class="form-label">Date of Birth</label>
      <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" required />
    </div>

    <div class="mb-3">
      <label for="gender" class="form-label">Gender</label>
      <select class="form-select" name="gender" id="gender" required>
        <option value="">Select</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        <option value="Other">Other</option>
      </select>
    </div>

    <div class="mb-3">
      <label for="contact_number" class="form-label">Contact Number</label>
      <input type="text" class="form-control" name="contact_number" id="contact_number" required />
    </div>

    <div class="mb-3">
      <label for="email" class="form-label">Email</label>
      <input type="email" class="form-control" name="email" id="email" required />
    </div>

    <div class="mb-3">
      <label for="address" class="form-label">Address</label>
      <input type="text" class="form-control" name="address" id="address" required />
    </div>

    <div class="mb-3">
      <label for="profile_picture" class="form-label">Profile Picture</label>
      <input type="file" class="form-control" name="profile_picture" id="profile_picture" accept="image/*" />
    </div>

    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
