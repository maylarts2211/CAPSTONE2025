<?php
include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';


// DB config
$host = "localhost";
$username = "root";
$password = "";
$dbname = "sk_bin";

$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert feedback if submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_feedback'])) {
    $gmail = $_POST['gmail'];
    $full_name = $_POST['full_name'];
    $barangay_id = $_POST['barangay_id'];
    $category = $_POST['category'];
    $message = $_POST['message'];

    $stmt = $conn->prepare("INSERT INTO sk_feedback (gmail, full_name, barangay_id, category, message, date_submitted) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("ssiss", $gmail, $full_name, $barangay_id, $category, $message);
    $stmt->execute();
    $stmt->close();
}

// Fetch barangays
$barangays = [];
$result = $conn->query("SELECT id, brgy_name FROM barangay ORDER BY brgy_name ASC");
while ($row = $result->fetch_assoc()) {
    $barangays[] = $row;
}

// Fetch feedback
$feedbacks = [];
$sql = "SELECT f.id, f.full_name, f.category, b.brgy_name AS barangay_name, f.date_submitted, f.message 
        FROM sk_feedback f
        LEFT JOIN barangay b ON f.barangay_id = b.id
        ORDER BY f.date_submitted DESC";
$result = $conn->query($sql);
while ($row = $result->fetch_assoc()) {
    $feedbacks[] = $row;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>SK Feedback Management</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  
  <!-- DataTables CSS -->
  <link href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css" rel="stylesheet" />
</head>
<body>


  
<div class="container mt-4">
  <!-- Header Buttons -->
  <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
    <!-- Youth Feedback Button -->
    <a href="feedback_management.php" class="btn btn-outline-primary fw-semibold rounded-pill px-4 shadow-sm" title="Go to Youth Feedback Page">
      <i class="fas fa-comments me-2"></i> Youth Feedback
    </a>

    <!-- Add Feedback Button -->
    <button class="btn btn-success rounded-pill px-4 shadow-sm" data-bs-toggle="modal" data-bs-target="#addFeedbackModal">
      <i class="fas fa-plus-circle me-2"></i> Add Feedback
    </button>
  </div>

  <!-- Feedback Table Card -->
  <div class="card shadow-sm border-0">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered table-hover mb-0" id="feedbackTable" style="width:100%">
          <thead class="table-dark text-center">
            <!-- Table Header Row -->
            <tr>
              <th style="width:5%;">ID</th>
              <th style="width:20%;">Name</th>
              <th style="width:15%;">Category</th>
              <th style="width:15%;">Barangay</th>
              <th style="width:15%;">Date</th>
              <th style="width:10%;">Actions</th>
              <th style="display:none;">Message</th>
            </tr>
          </thead>
          <tbody class="text-center align-middle">
            <?php foreach ($feedbacks as $fb): ?>
              <tr>
                <td><?= htmlspecialchars($fb['id']) ?></td>
                <td class="text-start"><?= htmlspecialchars($fb['full_name']) ?></td>
                <td><?= htmlspecialchars($fb['category']) ?></td>
                <td><?= htmlspecialchars($fb['barangay_name']) ?></td>
                <td><?= htmlspecialchars(date('Y-m-d', strtotime($fb['date_submitted']))) ?></td>
                <td>
                  <button class="btn btn-sm btn-info" onclick="viewFeedback(this)" title="View Feedback">
                    <i class="fas fa-eye"></i>
                  </button>
                </td>
                <td style="display:none;" class="feedback-message"><?= htmlspecialchars($fb['message']) ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- View Feedback Modal -->
<div class="modal fade" id="feedbackModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title">Feedback Details</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <p><strong>ID:</strong> <span id="modalId"></span></p>
        <p><strong>Name:</strong> <span id="modalName"></span></p>
        <p><strong>Type:</strong> <span id="modalType"></span></p>
        <p><strong>Barangay:</strong> <span id="modalBarangay"></span></p>
        <p><strong>Date:</strong> <span id="modalDate"></span></p>
        <hr />
        <p><strong>Feedback Content:</strong></p>
        <p id="modalContent"></p>
      </div>
    </div>
  </div>
</div>

<!-- Add Feedback Modal -->
<div class="modal fade" id="addFeedbackModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <form method="POST" class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title">Add Feedback</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
          <label>Email</label>
          <input type="email" name="gmail" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Full Name</label>
          <input type="text" name="full_name" class="form-control" required>
        </div>
        <div class="mb-3">
          <label>Barangay</label>
          <select name="barangay_id" class="form-select" required>
            <option value="">Select Barangay</option>
            <?php foreach ($barangays as $b): ?>
              <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['brgy_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-3">
          <label>Category</label>
          <select name="category" class="form-select" required>
            <option value="Comment">Comment</option>
            <option value="Suggestion">Suggestion</option>
            <option value="Complaint">Complaint</option>
            <option value="Praise">Praise</option>
          </select>
        </div>
        <div class="mb-3">
          <label>Message</label>
          <textarea name="message" class="form-control" rows="3" required></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button type="submit" name="submit_feedback" class="btn btn-success">Submit</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<!-- jQuery (required for DataTables) -->
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>

<script>
let table;

$(document).ready(function() {
  // Initialize DataTable
  table = $('#feedbackTable').DataTable({
    "order": [[4, "desc"]], // default order by Date desc
    "columnDefs": [
      { "targets": 6, "visible": false }, // Hide message column
      { "orderable": false, "targets": 5 } // Actions column not orderable
    ]
  });

  // Filter button event - apply filtering on Category and Barangay columns
  $('#filterBtn').on('click', function() {
    let category = $('#typeFilter').val();
    let barangay = $('#barangayFilter').val();

    // Clear all previous filters
    table.columns().search('');

    if (category) {
      // Category is column 2 (0-based)
      table.column(2).search('^' + category + '$', true, false); // exact match
    }
    if (barangay) {
      // Barangay is column 3 (0-based)
      table.column(3).search('^' + barangay + '$', true, false); // exact match
    }
    table.draw();
  });
});

function viewFeedback(button) {
  const row = $(button).closest('tr');
  const data = table.row(row).data();

  // data array mapping:
  // 0 - ID
  // 1 - Name
  // 2 - Category
  // 3 - Barangay
  // 4 - Date
  // 5 - Actions button HTML
  // 6 - Message (hidden)

  $('#modalId').text(data[0]);
  $('#modalName').text(data[1]);
  $('#modalType').text(data[2]);
  $('#modalBarangay').text(data[3]);
  $('#modalDate').text(data[4]);
  $('#modalContent').text(data[6]);

  new bootstrap.Modal(document.getElementById('feedbackModal')).show();
}
</script>
</body>
</html>
