<?php
// Database connection — replace with your actual credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sk_bin";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch barangays from the database
$barangays = [];
$sql = "SELECT id, brgy_name FROM barangay ORDER BY brgy_name ASC";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $barangays[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html>
<head>
    <title>SK Feedback Form</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h3>Sangguniang Kabataan Feedback Form</h3>
    <p class="text-muted">All fields are required.</p>
    <form id="feedbackForm">
        <div class="mb-3">
            <label><strong>Gmail Address</strong></label>
            <input type="email" name="gmail" class="form-control" required pattern=".+@gmail\.com" placeholder="example@gmail.com">
        </div>
        <div class="mb-3">
            <label><strong>Full Name</strong></label>
            <input type="text" name="full_name" class="form-control" required>
        </div>
        <div class="mb-3">
            <label><strong>Barangay</strong></label>
            <select name="barangay" class="form-control" required>
                <option value="">-- Select Barangay --</option>
                <?php foreach ($barangays as $b): ?>
                    <option value="<?= htmlspecialchars($b['id']) ?>"><?= htmlspecialchars($b['brgy_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label><strong>Type of Feedback</strong></label>
            <select name="category" class="form-control" required>
                <option value="">-- Select Type --</option>
                <option value="Comment">Comment</option>
                <option value="Suggestion">Suggestion</option>
                <option value="Complaint">Complaint</option>
            </select>
        </div>
        <div class="mb-3">
            <label><strong>Your Message</strong></label>
            <textarea name="message" class="form-control" rows="4" required></textarea>
        </div>
        <button type="submit" class="btn btn-success">Submit Feedback</button>
        <div id="responseMsg" class="mt-3"></div>
    </form>

<script>
document.getElementById("feedbackForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const formData = new FormData(this);

    fetch('submit_feedback.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        document.getElementById("responseMsg").innerHTML = data;
        this.reset();
    });
});

// Auto-select barangay if present in the URL by id (numeric)
const urlParams = new URLSearchParams(window.location.search);
const preselectedBarangay = urlParams.get('barangay');
if (preselectedBarangay) {
    const barangaySelect = document.querySelector('select[name="barangay"]');
    if (barangaySelect) {
        barangaySelect.value = preselectedBarangay;
    }
}
</script>

</body>
</html>
