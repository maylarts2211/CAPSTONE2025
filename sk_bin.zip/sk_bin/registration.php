<?php
include('includes/config.php');  // Include database connection

session_start();
$message = "";

// Registration handler
if (isset($_POST['register'])) {
    $username = htmlspecialchars(trim($_POST["reg_username"]));
    $password = htmlspecialchars(trim($_POST["reg_password"]));

    if ($username && $password) {
        // Check if the username already exists in the database
        $stmt = $pdo->prepare("SELECT id FROM user WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->rowCount() > 0) {
            $message = "<div class='alert'>Username already exists.</div>";
        } else {
            // Hash the password before storing
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user into the database
            $stmt = $pdo->prepare("INSERT INTO user (username, password) VALUES (?, ?)");
            if ($stmt->execute([$username, $hashed_password])) {
                $message = "<div class='success'>Registration successful. <a href='index.php'>Login here</a>.</div>";
            } else {
                $message = "<div class='alert'>Error registering user.</div>";
            }
        }
    } else {
        $message = "<div class='alert'>Please fill in all fields.</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            background: linear-gradient(to right, #667eea, #764ba2);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: #333;
        }
        .card {
            background: #fff;
            padding: 2rem;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            text-align: center;
            margin-bottom: 1.5rem;
            font-weight: 600;
            color: #333;
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-group label {
            display: block;
            font-weight: 500;
            margin-bottom: 0.5rem;
        }
        .form-control {
            width: 100%;
            padding: 0.75rem;
            border-radius: 8px;
            border: 1px solid #ccc;
        }
        .btn {
            width: 100%;
            padding: 0.75rem;
            background: #667eea;
            color: white;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.3s;
        }
        .btn:hover {
            background: #5a67d8;
        }
        .text-center {
            text-align: center;
            margin-top: 1rem;
        }
        .text-center a {
            color: #667eea;
            text-decoration: none;
        }
        .text-center a:hover {
            text-decoration: underline;
        }
        .alert {
            background-color: #ffdddd;
            color: #a94442;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
        .success {
            background-color: #ddffdd;
            color: #3c763d;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Create an Account</h2>

    <?php echo $message; ?>

    <form method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="reg_username" class="form-control" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="reg_password" class="form-control" required>
        </div>
        <button type="submit" name="register" class="btn">Register</button>
    </form>

    <p class="text-center">Already registered? <a href="index.php">Login here</a></p>
</div>

</body>
</html>
