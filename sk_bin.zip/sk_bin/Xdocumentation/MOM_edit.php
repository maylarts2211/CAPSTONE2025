<?php
// 1. Connect to your DB
include '../includes/db_connection.php'; // your connection file

// 2. Get the mom_id from GET
$mom_id = (int)($_GET['mom_id'] ?? 0);
if ($mom_id <= 0) {
    die("Invalid ID");
}

// 3. Fetch existing record
$sql = "SELECT * FROM tbl_mom WHERE mom_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $mom_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Record not found.");
}

$mom = $result->fetch_assoc();
$stmt->close();

// 4. Show the form with pre-filled values
?>

<form action="update_mom.php" method="post">
    <input type="hidden" name="mom_id" value="<?php echo $mom['mom_id']; ?>">

    Title:<br>
    <input type="text" name="meeting_type" value="<?php echo htmlspecialchars($mom['mom_title']); ?>" required><br>

    Date & Time:<br>
    <input type="datetime-local" name="meeting_datetime" value="<?php echo date('Y-m-d\TH:i', strtotime($mom['mom_datetime'])); ?>" required><br>

    Location:<br>
    <input type="text" name="location" value="<?php echo htmlspecialchars($mom['mom_location']); ?>" required><br>

    Presiding Officer:<br>
    <input type="text" name="presiding_officer" value="<?php echo htmlspecialchars($mom['mom_presiding_officer']); ?>" required><br>

    Secretary:<br>
    <input type="text" name="secretary" value="<?php echo htmlspecialchars($mom['mom_secretary']); ?>" required><br>

    Attendees Count:<br>
    <input type="number" name="present_count" value="<?php echo (int)$mom['mom_attendees_count']; ?>" required><br>

    Agenda Summary:<br>
    <textarea name="agenda_summary"><?php echo htmlspecialchars($mom['mom_agenda_summary']); ?></textarea><br>

    Agenda 1:<br>
    <input type="text" name="agenda_1" value="<?php echo htmlspecialchars($mom['mom_agenda_1']); ?>"><br>

    Agenda 2:<br>
    <input type="text" name="agenda_2" value="<?php echo htmlspecialchars($mom['mom_agenda_2']); ?>"><br>

    Agenda 3:<br>
    <input type="text" name="agenda_3" value="<?php echo htmlspecialchars($mom['mom_agenda_3']); ?>"><br>

    Agenda 4:<br>
    <input type="text" name="agenda_4" value="<?php echo htmlspecialchars($mom['mom_agenda_4']); ?>"><br>

    Other Matters:<br>
    <textarea name="other_matters"><?php echo htmlspecialchars($mom['mom_other_matters']); ?></textarea><br>

    Adjournment:<br>
    <textarea name="adjournment"><?php echo htmlspecialchars($mom['mom_adjournment']); ?></textarea><br>

    <!-- Attachment file handling can be added here -->

    <button type="submit">Update</button>
</form>
