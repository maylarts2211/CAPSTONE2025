<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>

<div class="container-fluid mt-4">
    <div class="card shadow mb-4">

        <!-- Card Header with Title -->
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">SK Annual Report</h6>
        </div>

        <!-- Search and Filter (moved below the header) -->
        <div class="card-body border rounded shadow-sm mb-3 no-print" style="background-color: #f8f9fa;">
            <div class="row align-items-center">
                <div class="col-md-3 mb-2 mb-md-0">
                    <input type="text" id="customSearch" class="form-control" placeholder="Search tasks...">
                </div>
                <div class="col-md-3 mb-2 mb-md-0">
                    <select id="statusFilter" class="form-control">
                        <option value="">All Status</option>
                        <option value="Completed">Completed</option>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Upcoming">Upcoming</option>
                    </select>
                </div>
                <div class="col-md-3 mb-2 mb-md-0">
                    <select id="taskFilter" class="form-control">
                        <option value="all">Show All</option>
                        <option value="5">Show 5</option>
                        <option value="10">Show 10</option>
                        <option value="15">Show 15</option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Card Body with Table -->
        <div class="card-body">
            <div class="table-responsive">
                <table id="annualReportTable" class="table table-bordered table-striped" width="100%" cellspacing="0">
                    <thead class="thead-dark">
                        <tr>
                            <th>Project Title</th>
                            <th>Date Implemented</th>
                            <th>Barangay</th>
                            <th>Total Budget</th>
                            <th>Youth Benefited</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $projects = [
                            ['Youth Leadership Seminar', '2024-03-05', 'Barangay Uno', '₱10,000.00', 50, 'Completed'],
                            ['SK Clean-Up Drive', '2024-04-12', 'Barangay Dos', '₱3,000.00', 40, 'Completed'],
                            ['Basketball Tournament', '2024-05-20', 'Barangay Tres', '₱15,000.00', 80, 'Completed'],
                            ['Mental Health Awareness', '2024-07-08', 'Barangay Uno', '₱5,000.00', 60, 'Completed'],
                            ['Livelihood Training', '2024-09-10', 'Barangay Dos', '₱12,000.00', 30, 'Ongoing'],
                            ['Tree Planting Project', '2024-10-15', 'Barangay Tres', '₱4,500.00', 35, 'Completed'],
                            ['Year-End Youth Summit', '2024-12-05', 'Federation-wide', '₱20,000.00', 100, 'Completed'],
                            ['Sports Festival', '2024-11-02', 'Barangay Cuatro', '₱8,000.00', 120, 'Completed'],
                            ['Community Health Outreach', '2025-01-15', 'Barangay Cinco', '₱7,500.00', 55, 'Completed'],
                            ['Leadership Workshop', '2025-02-10', 'Barangay Seis', '₱6,000.00', 45, 'Completed'],
                        ];

                        foreach ($projects as $p) {
                            echo "<tr>
                                <td>{$p[0]}</td>
                                <td>{$p[1]}</td>
                                <td>{$p[2]}</td>
                                <td>{$p[3]}</td>
                                <td>{$p[4]}</td>
                                <td>{$p[5]}</td>
                            </tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <!-- Print Button -->
            <button class="btn btn-success mt-3 no-print" onclick="window.print();">Print Report</button>
        </div>
    </div>
</div>

<!-- Print Styles -->
<style>
    @media print {
        body * {
            visibility: hidden !important;
        }

        #annualReportTable_wrapper,
        #annualReportTable_wrapper *,
        #reportHeader {
            visibility: visible !important;
        }

        #reportHeader {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            text-align: center;
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 20px;
        }

        #annualReportTable_wrapper {
            position: absolute;
            top: 100px;
            left: 0;
            width: 100%;
        }

        .no-print,
        .btn,
        #statusFilter,
        #customSearch {
            display: none !important;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            font-size: 12px;
        }

        th,
        td {
            border: 1px solid #000;
            padding: 4px;
        }
    }

    #customSearch,
    #statusFilter,
    #taskFilter,
    #customLengthWrapper select {
        border-radius: 8px;
        padding: 6px 12px;
    }

    .dataTables_filter {
        display: none !important;
    }
</style>

<?php include('includes/footer.php'); ?>

<!-- Scripts -->
<script>
    $(document).ready(function () {
        var table = $('#annualReportTable').DataTable({
            responsive: true,
            autoWidth: false,
            paging: true,
            lengthChange: true,
            searching: true,
            ordering: true,
            info: true,
            lengthMenu: [
                [-1, 5, 10, 15], ['Show All', 'Show 5', 'Show 10', 'Show 15']
            ]
        });

        // Move the length dropdown beside status filter
        $('#annualReportTable_wrapper .dataTables_length').appendTo('#customLengthWrapper');

        // Custom search (for all columns)
        $('#customSearch').on('keyup', function () {
            table.search(this.value).draw();
        });

        // Status filter (for status column)
        $('#statusFilter').on('change', function () {
            var selected = $(this).val();
            if (selected) {
                table.column(5).search('^' + selected + '$', true, false).draw();
            } else {
                table.column(5).search('').draw();
            }
        });

        // Handle Show All filter functionality
        $('#taskFilter').on('change', function () {
            var value = $(this).val();
            if (value === 'all') {
                table.page.len(-1).draw(); // Show all rows
            } else {
                table.page.len(value).draw(); // Limit rows based on user selection
            }
        });
    });
</script>
