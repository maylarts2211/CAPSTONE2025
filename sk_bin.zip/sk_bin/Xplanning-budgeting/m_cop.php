<?php
// Display errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connect to DB
$conn = new mysqli("localhost", "root", "", "sk_bin");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle Add
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['add_cop'])) {
    $cop_name = trim($_POST['cop_name']);
    $cop_description = trim($_POST['cop_description']);
    if ($cop_name !== "" && $cop_description !== "") {
        $stmt = $conn->prepare("INSERT INTO tbl_cop (cop_name, cop_description, cop_created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("ss", $cop_name, $cop_description);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: m_cop.php");
    exit();
}

// Handle Archive
if (isset($_GET['archive_id'])) {
    $archive_id = intval($_GET['archive_id']);
    $conn->query("DELETE FROM tbl_cop WHERE cop_id = $archive_id");
    header("Location: m_cop.php");
    exit();
}

// Handle Edit
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update_cop'])) {
    $cop_id = intval($_POST['cop_id']);
    $cop_name = trim($_POST['cop_name']);
    $cop_description = trim($_POST['cop_description']);
    if ($cop_name !== "" && $cop_description !== "") {
        $stmt = $conn->prepare("UPDATE tbl_cop SET cop_name=?, cop_description=? WHERE cop_id=?");
        $stmt->bind_param("ssi", $cop_name, $cop_description, $cop_id);
        $stmt->execute();
        $stmt->close();
    }
    header("Location: m_cop.php");
    exit();
}

// Fetch Data for View/Edit
$copData = null;
if (isset($_GET['view_id']) || isset($_GET['edit_id'])) {
    $id = intval($_GET['view_id'] ?? $_GET['edit_id']);
    $result = $conn->query("SELECT * FROM tbl_cop WHERE cop_id = $id LIMIT 1");
    if ($result && $result->num_rows > 0) {
        $copData = $result->fetch_assoc();
    }
}

// Now include files that generate output
include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';
?>



<div class="container-fluid mt-4">
    <!-- Your existing header and add button... (unchanged) -->
    <div class="card-body py-1 px-0 border-bottom d-flex justify-content-between align-items-center flex-wrap">
        <?php $currentPage = basename($_SERVER['PHP_SELF']); ?>
          <div class="d-flex gap-1 flex-wrap align-items-center">
          <a href="m_CBYDP.php" 
                class="btn btn-sm <?php echo (basename($_SERVER['PHP_SELF']) == 'm_CBYDP.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2" 
                title="COMPREHENSIVE BARANGAY YOUTH DEVELOPMENT PLANNING" 
                data-bs-toggle="tooltip" 
                data-bs-placement="top">
                    CBYDP
                </a>

                <a href="m_ABYIP.php" 
                class="btn btn-sm <?php echo (basename($_SERVER['PHP_SELF']) == 'm_ABYIP.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2" 
                title="ANNUAL BARANGAY YOUTH INVESTMENT PROGRAM" 
                data-bs-toggle="tooltip" 
                data-bs-placement="top">
                    ABYIP
                </a>   
          <a href="m_cop.php" class="btn btn-sm <?= $currentPage === 'm_cop.php' ? 'btn-primary' : 'btn-outline-primary' ?> rounded-pill px-4 py-2">Center of Participation</a>
          </div>

        <div class="d-flex align-items-center gap-2">
  <button type="button" class="btn btn-sm btn-primary fw-semibold rounded-pill px-4 py-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#addCopModal">
    <i class="fas fa-plus-circle"></i> Add
  </button>
  <button type="button" class="btn btn-sm btn-danger fw-semibold rounded-pill px-4 py-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#archiveModal">
    <i class="fas fa-archive"></i> Archive
  </button>
</div>

    </div>

    <div class="card shadow-sm mt-3">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover align-middle text-center" id="copTable" style="width:100%">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Pillar</th>
                            <th>Agenda Statement</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM tbl_cop ORDER BY cop_created_at DESC";
                        $result = $conn->query($query);
                        if ($result && $result->num_rows > 0) {
                            $count = 1;
                            while ($row = $result->fetch_assoc()) {
                                $formatted_date = date("M d, Y h:i A", strtotime($row['cop_created_at']));
                                $description = htmlspecialchars($row['cop_description']);
                                $truncated_desc = strlen($description) > 50 ? substr($description, 0, 50) . '...' : $description;

                                echo "<tr>
                                    <td>" . $count++ . "</td>
                                    <td>" . htmlspecialchars($row['cop_name']) . "</td>
                                    <td>
                                        <span data-bs-toggle='tooltip' title='" . $description . "' style='display: inline-block; max-width: 200px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;'>
                                            " . $truncated_desc . "
                                        </span>
                                    </td>
                                                                  <td>
                                  <span class='badge badge-primary'>
                                    " . htmlspecialchars($formatted_date) . "
                                  </span>
                                </td>
                                <td>
                                        <a href='?view_id=" . urlencode($row['cop_id']) . "' class='btn btn-sm btn-primary' data-bs-toggle='tooltip' title='View'><i class='fas fa-eye'></i></a>
                                        <a href='?edit_id=" . urlencode($row['cop_id']) . "' class='btn btn-sm btn-warning' data-bs-toggle='tooltip' title='Edit'><i class='fas fa-edit'></i></a>
                                        <a href='?archive_id=" . urlencode($row['cop_id']) . "' class='btn btn-sm btn-danger' data-bs-toggle='tooltip' title='Archive' onclick=\"return confirm('Are you sure you want to archive this record?');\"><i class='fas fa-archive'></i></a>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-muted'>No participation records found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- View Modal -->
<?php if (isset($_GET['view_id']) && $copData): ?>
<div class="modal show" style="display:block; background: rgba(0,0,0,0.5);">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">View Center of Participation</h5>
                <a href="m_cop.php" class="btn-close"></a>
            </div>
            <div class="modal-body">
                <p><strong>Pillar:</strong> <?= htmlspecialchars($copData['cop_name']) ?></p>
                <p><strong>Agenda Statement:</strong> <?= nl2br(htmlspecialchars($copData['cop_description'])) ?></p>
                <p><strong>Created At:</strong> <?= htmlspecialchars($copData['cop_created_at']) ?></p>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Edit Modal -->
<?php if (isset($_GET['edit_id']) && $copData): ?>
<div class="modal show" style="display:block; background: rgba(0,0,0,0.5);">
    <div class="modal-dialog">
        <form method="POST" class="modal-content needs-validation" novalidate>
            <div class="modal-header">
                <h5 class="modal-title">Edit Center of Participation</h5>
                <a href="m_cop.php" class="btn-close"></a>
            </div>
            <div class="modal-body">
                <input type="hidden" name="cop_id" value="<?= $copData['cop_id'] ?>">
                <div class="mb-3">
                    <label for="cop_name" class="form-label">Pillar</label>
                    <input type="text" class="form-control" name="cop_name" value="<?= htmlspecialchars($copData['cop_name']) ?>" required>
                    <div class="invalid-feedback">Please enter a title.</div>
                </div>
                <div class="mb-3">
                    <label for="cop_description" class="form-label">Agenda Statement</label>
                    <textarea class="form-control" name="cop_description" rows="3" required><?= htmlspecialchars($copData['cop_description']) ?></textarea>
                    <div class="invalid-feedback">Please enter a description.</div>
                </div>
            </div>
            <div class="modal-footer">
                <a href="m_cop.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" name="update_cop" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- Add Modal (existing, unchanged) -->
<div class="modal fade" id="addCopModal" tabindex="-1" aria-labelledby="addCopModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form method="POST" class="modal-content needs-validation" novalidate>
            <div class="modal-header">
                <h5 class="modal-title" id="addCopModalLabel">Add New Center of Participation</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label for="cop_name" class="form-label">Title</label>
                    <input type="text" class="form-control" id="cop_name" name="cop_name" required>
                    <div class="invalid-feedback">Please enter a title.</div>
                </div>
                <div class="mb-3">
                    <label for="cop_description" class="form-label">Description</label>
                    <textarea class="form-control" id="cop_description" name="cop_description" rows="3" required></textarea>
                    <div class="invalid-feedback">Please enter a description.</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="submit" name="add_cop" class="btn btn-primary">Add</button>
            </div>
        </form>
    </div>
</div>

<?php
include '../includes/footer.php'; ?>


<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
<script>
    (() => {
        'use strict'
        const forms = document.querySelectorAll('.needs-validation')
        Array.from(forms).forEach(form => {
            form.addEventListener('submit', event => {
                if (!form.checkValidity()) {
                    event.preventDefault()
                    event.stopPropagation()
                }
                form.classList.add('was-validated')
            }, false)
        })
    })();

    $(document).ready(function() {
        $('#copTable').DataTable({
            order: [[3, "desc"]],
            columnDefs: [{ orderable: false, targets: [4] }]
        });
        $('[data-bs-toggle="tooltip"]').tooltip();
    });
</script>
<script>
  // Enable Bootstrap tooltips
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
    return new bootstrap.Tooltip(tooltipTriggerEl);
  });
</script>