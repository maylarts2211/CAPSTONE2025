<?php
include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';

?>

<div class="container-fluid mt-4">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center flex-wrap">
      <div class="d-flex gap-1 flex-wrap align-items-center">
        <a href="m_CBYDP.php" 
          class="btn btn-sm <?php echo (basename($_SERVER['PHP_SELF']) == 'm_CBYDP.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2" 
          title="COMPREHENSIVE BARANGAY YOUTH DEVELOPMENT PLANNING" 
          data-bs-toggle="tooltip" 
          data-bs-placement="top">
          CBYDP
        </a>

        <a href="m_ABYIP.php" 
          class="btn btn-sm <?php echo (basename($_SERVER['PHP_SELF']) == 'm_ABYIP.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2" 
          title="ANNUAL BARANGAY YOUTH INVESTMENT PROGRAM" 
          data-bs-toggle="tooltip" 
          data-bs-placement="top">
          ABYIP
        </a>

        <a href="m_cop.php" 
          class="btn btn-sm <?php echo (basename($_SERVER['PHP_SELF']) == 'm_cop.php') ? 'btn-primary fw-semibold' : 'btn-outline-primary'; ?> rounded-pill px-4 py-2">
          Center of Participation
        </a>
      </div>

      <div class="d-flex gap-2">
        <button type="button" class="btn btn-sm btn-primary fw-semibold rounded-pill px-4 py-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#addCopModal">
    <i class="fas fa-plus-circle"></i> Add
  </button>
  <button type="button" class="btn btn-sm btn-danger fw-semibold rounded-pill px-4 py-2 shadow-sm" data-bs-toggle="modal" data-bs-target="#archiveModal">
    <i class="fas fa-archive"></i> Archive
  </button>
      </div>
    </div>

    
    <div class="card-body">
      <div class="table-responsive">
        <table id="copTable" class="table table-bordered table-hover">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>Center Of Participation</th>
              <th>Agenda Statement</th>
              <th>Year</th>
              <th>Attachment</th>
              <th>Action</th>
            </tr>
          </thead>
<tbody>
  <tr>
    <td>1</td>
    <td>Health</td>
    <td>Promotes youth physical ...
    <td>2026-2028</td>
    <td>
      <a href="#" target="_blank" data-bs-toggle="tooltip" title="View Attachment">
        <i class="fas fa-file-alt"></i>
      </a>
    </td>
    <td>
      <form method="POST" action="view.php" style="display:inline;">
        <input type="hidden" name="id" value="1">
        <button type="submit" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="View">
          <i class="fas fa-eye"></i>
        </button>
      </form>
      <form method="POST" action="edit.php" style="display:inline;">
        <input type="hidden" name="id" value="1">
        <button type="submit" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
          <i class="fas fa-edit"></i>
        </button>
      </form>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to archive this record?');">
        <input type="hidden" name="archive_id" value="1">
        <button type="submit" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Archive">
          <i class="fas fa-archive"></i>
        </button>
      </form>
    </td>
  </tr>

  <tr>
    <td>2</td>
    <td>Education</td>
    <td>Improves access to ...</td>
    <td>2026-2028</td>
    <td>
      <a href="#" target="_blank" data-bs-toggle="tooltip" title="View Attachment">
        <i class="fas fa-file-alt"></i>
      </a>
    </td>
    <td>
      <form method="POST" action="view.php" style="display:inline;">
        <input type="hidden" name="id" value="2">
        <button type="submit" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="View">
          <i class="fas fa-eye"></i>
        </button>
      </form>
      <form method="POST" action="edit.php" style="display:inline;">
        <input type="hidden" name="id" value="2">
        <button type="submit" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
          <i class="fas fa-edit"></i>
        </button>
      </form>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to archive this record?');">
        <input type="hidden" name="archive_id" value="2">
        <button type="submit" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Archive">
          <i class="fas fa-archive"></i>
        </button>
      </form>
    </td>
  </tr>

  <tr>
    <td>3</td>
    <td>Environment</td>
    <td>Supports protection ...</td>
    <td>2026-2028</td>
    <td>
      <a href="#" target="_blank" data-bs-toggle="tooltip" title="View Attachment">
        <i class="fas fa-file-alt"></i>
      </a>
    </td>
    <td>
      <form method="POST" action="view.php" style="display:inline;">
        <input type="hidden" name="id" value="3">
        <button type="submit" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="View">
          <i class="fas fa-eye"></i>
        </button>
      </form>
      <form method="POST" action="edit.php" style="display:inline;">
        <input type="hidden" name="id" value="3">
        <button type="submit" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
          <i class="fas fa-edit"></i>
        </button>
      </form>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to archive this record?');">
        <input type="hidden" name="archive_id" value="3">
        <button type="submit" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Archive">
          <i class="fas fa-archive"></i>
        </button>
      </form>
    </td>
  </tr>

  <tr>
    <td>4</td>
    <td>Livelihood</td>
    <td>Enhances youth skills...</td>
    <td>2026-2028</td>
    <td>
      <a href="#" target="_blank" data-bs-toggle="tooltip" title="View Attachment">
        <i class="fas fa-file-alt"></i>
      </a>
    </td>
    <td>
      <form method="POST" action="view.php" style="display:inline;">
        <input type="hidden" name="id" value="4">
        <button type="submit" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="View">
          <i class="fas fa-eye"></i>
        </button>
      </form>
      <form method="POST" action="edit.php" style="display:inline;">
        <input type="hidden" name="id" value="4">
        <button type="submit" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
          <i class="fas fa-edit"></i>
        </button>
      </form>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to archive this record?');">
        <input type="hidden" name="archive_id" value="4">
        <button type="submit" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Archive">
          <i class="fas fa-archive"></i>
        </button>
      </form>
    </td>
  </tr>

  <tr>
    <td>5</td>
    <td>Sports & Recreation</td>
    <td>Encourages active ...</td>
    <td>2026-2028</td>
    <td>
      <a href="#" target="_blank" data-bs-toggle="tooltip" title="View Attachment">
        <i class="fas fa-file-alt"></i>
      </a>
    </td>
    <td>
      <form method="POST" action="view.php" style="display:inline;">
        <input type="hidden" name="id" value="5">
        <button type="submit" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="View">
          <i class="fas fa-eye"></i>
        </button>
      </form>
      <form method="POST" action="edit.php" style="display:inline;">
        <input type="hidden" name="id" value="5">
        <button type="submit" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Edit">
          <i class="fas fa-edit"></i>
        </button>
      </form>
      <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to archive this record?');">
        <input type="hidden" name="archive_id" value="5">
        <button type="submit" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Archive">
          <i class="fas fa-archive"></i>
        </button>
      </form>
    </td>
  </tr>
</tbody>




        </table>
      </div>
    </div>
  </div>
</div>

<!-- Add Center of Participation Modal -->
<div class="modal fade" id="addCopModal" tabindex="-1" aria-labelledby="addCopModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <form action="add_cop.php" method="POST" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title fw-semibold" id="addCopModalLabel">Add Center of Participation</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>

        <div class="modal-body">
          <div class="row g-3">
            
            <div class="mb-3">
  <div class="mb-3">
  <label class="form-label"></label>

  <div class="d-flex gap-2 align-items-center mb-2">
    <input type="number" class="form-control" name="year1" placeholder="Year" style="max-width: 120px;" required>
    <input type="number" class="form-control" name="youth1" placeholder="Youth" style="max-width: 120px;" required>
  </div>

  <div class="d-flex gap-2 align-items-center mb-2">
    <input type="number" class="form-control" name="year2" placeholder="Year" style="max-width: 120px;" required>
    <input type="number" class="form-control" name="youth2" placeholder="Youth" style="max-width: 120px;" required>
  </div>

  <div class="d-flex gap-2 align-items-center">
    <input type="number" class="form-control" name="year3" placeholder="Year" style="max-width: 120px;" required>
    <input type="number" class="form-control" name="youth3" placeholder="Youth" style="max-width: 120px;" required>
  </div>
</div>



            <div class="col-12">
              <label class="form-label"></label>
              <div class="d-flex gap-2">
                <select class="form-select" name="center_of_participation" required>
                  <option value="" selected disabled>Select Center of Participation</option>
                  <option value="Health">Health</option>
                  <option value="Environment">Environment</option>
                  <option value="Education">Education</option>
                  <option value="Culture and Arts">Culture and Arts</option>
                  <option value="Sports and Recreation">Sports and Recreation</option>
                  <option value="Social Welfare">Social Welfare</option>
                  <option value="Economic Development">Economic Development</option>
                  <option value="Peace and Order">Peace and Order</option>
                  <option value="Governance">Governance</option>
                </select>

                <input type="text" class="form-control" name="agenda_statement" placeholder="Agenda Statement" required>
              </div>
            </div>

            <div class="col-12">
              <label class="form-label"></label>
              <div class="d-flex gap-2">
                <input type="text" class="form-control" name="youth_concern" placeholder="Youth Development Concern" required>
                <input type="text" class="form-control" name="ppa" placeholder="PPA" required>
              </div>
            </div>

            <div class="col-12">
              <label class="form-label"></label>
              <div class="d-flex gap-2">
                <input type="text" class="form-control" name="budget" placeholder="Budget" required>
                <input type="text" class="form-control" name="person_responsible" placeholder="Person Responsible" required>
              </div>
            </div>

            <div class="col-12">
              <label class="form-label"></label>
              <input type="text" class="form-control" name="resolution" placeholder="Resolution" required>
            </div>

            <div class="col-12">
              <label class="form-label"></label>
              <input type="file" class="form-control" name="attachment">
            </div>

          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary">Save</button>
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>



<!-- DataTables JS -->
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

<!-- DataTables CSS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css" />

<script>
  $(document).ready(function() {
    $('#copTable').DataTable({
      responsive: true
    });

    // Enable Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });
  });
</script>
