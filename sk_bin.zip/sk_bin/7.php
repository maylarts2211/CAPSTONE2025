<?php
include('includes/connect.php');
session_start();

// Fetch youth records
$selectQuery = "SELECT * FROM youth ORDER BY created_at DESC";
$result = $conn->query($selectQuery);

if (!$result) {
    die("Database query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Youth Records</title>
  <?php include('includes/header.php'); ?>
</head>


  <?php
  include('includes/navbar.php');
  include('includes/topbar.php');
  ?>

  <div class="content-wrapper">
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">

            <a href="addyouth.php" class="btn btn-success btn-sm mb-2">
              <i class="fas fa-plus-circle"></i> Add Youth
            </a>

            <div class="card">
              <div class="card-header d-flex justify-content-between align-items-center">
                <h3 class="card-title">Youth Records</h3>
              </div>

              <div class="card-body">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Fullname</th>
                      <th>Contact</th>
                      <th>Email</th>
                      <th>Address</th>
                      <th>Barangay</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    if ($result->num_rows > 0) {
                        $counter = 1;
                        while ($row = $result->fetch_assoc()) {
                            $expiryDate = strtotime($row['expiry_date']);
                            $currentDate = time();
                            $daysDifference = floor(($expiryDate - $currentDate) / (60 * 60 * 24));
                            $status = ($daysDifference < 0) ? 'Expired' : 'Active';

                            // Sanitize output
                            $id = (int)$row['id']; // safer for numeric ID
                            $fullname = htmlspecialchars($row['fullname'], ENT_QUOTES, 'UTF-8');
                            $contact = htmlspecialchars($row['contact_number'], ENT_QUOTES, 'UTF-8');
                            $email = htmlspecialchars($row['email'], ENT_QUOTES, 'UTF-8');
                            $address = htmlspecialchars($row['address'], ENT_QUOTES, 'UTF-8');
                            $barangay = htmlspecialchars($row['barangay'], ENT_QUOTES, 'UTF-8');
                            $status = htmlspecialchars($status, ENT_QUOTES, 'UTF-8');

                            echo "<tr>
                                    <td>{$counter}</td>
                                    <td>{$fullname}</td>
                                    <td>{$contact}</td>
                                    <td>{$email}</td>
                                    <td>{$address}</td>
                                    <td>{$barangay}</td>
                                    <td>{$status}</td>
                                    <td>
                                      <a href='youthProfile.php?id={$id}' class='btn btn-info btn-sm' title='View'><i class='fas fa-id-card'></i></a>
                                      <a href='edit_youth.php?id={$id}' class='btn btn-primary btn-sm' title='Edit'><i class='fas fa-edit'></i></a>
                                      <button class='btn btn-danger btn-sm' onclick='deleteYouth(" . json_encode($id) . ")' title='Delete'><i class='fas fa-trash'></i></button>
                                    </td>
                                  </tr>";
                            $counter++;
                        }
                    } else {
                        echo "<tr><td colspan='8' class='text-center'>No records found.</td></tr>";
                    }
                    ?>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>
  </div>

  <?php include('includes/footer.php'); ?>

  <aside class="control-sidebar control-sidebar-dark"></aside>

</div>

<!-- JS Scripts -->
<script>
  $(function () {
    // Delay DataTables initialization to ensure content is ready
    setTimeout(function () {
      $('#example1').DataTable({
        responsive: true,
        autoWidth: false
      });
    }, 100);
  });

  function deleteYouth(id) {
    if (confirm("Are you sure you want to delete this youth record?")) {
      window.location.href = 'delete_youth.php?id=' + encodeURIComponent(id);
    }
  }
</script>

</body>
</html>
