<?php
$conn = new mysqli("localhost", "root", "", "sk_bin");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Archive record from main page
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['archive_id'])) {
    $id = (int)$_POST['archive_id'];
    $conn->query("UPDATE tbl_mom SET mom_archived = 1 WHERE mom_id = $id");
    header("Location: MOM_archive.php");
    exit;
}

// Restore record from archive
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['restore_id'])) {
    $id = (int)$_POST['restore_id'];
    $conn->query("UPDATE tbl_mom SET mom_archived = 0 WHERE mom_id = $id");
    header("Location: MOM_archive.php");
    exit;
}

// Now safe to include HTML
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>


<div class="container-fluid">
   
    <a href="MOM.php" class="btn btn-secondary fw-semibold rounded-pill mb-2"><i class="fas fa-arrow-left"></i> Back</a>

    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-bordered table-hover align-middle text-center" id="archivedTable">
                    <thead class="thead-dark">
                        <tr>
                            <th>#</th>
                            <th>Meeting Title</th>
                            <th>Date & Time</th>
                            <th>Attachment</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $query = "SELECT * FROM tbl_mom WHERE mom_archived = 1 ORDER BY mom_datetime DESC";
                        $result = $conn->query($query);
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $formatted_date = date("M d, Y h:i A", strtotime($row['mom_datetime']));
                                $file = $row['mom_attachment'] 
                                    ? "<a href='uploads/" . htmlspecialchars($row['mom_attachment']) . "' class='badge badge-success' target='_blank' data-toggle='tooltip' title='View Attachment'><i class='fas fa-file-alt'></i> View</a>" 
                                    : "<span class='text-muted'>None</span>";
                                
                                echo "<tr>
                                    <td>" . htmlspecialchars($row['mom_id']) . "</td>
                                    <td>" . htmlspecialchars($row['mom_title']) . "</td>
                                    <td><span class='badge badge-info'>$formatted_date</span></td>
                                    <td>$file</td>
                                    <td>
                                        <form method='POST' onsubmit=\"return confirm('Are you sure you want to restore this record?');\" style='display:inline;'>
                                            <input type='hidden' name='restore_id' value='" . htmlspecialchars($row['mom_id']) . "'>
                                            <button type='submit' class='btn btn-sm btn-success' data-toggle='tooltip' title='Restore Record'><i class='fas fa-undo'></i></button>
                                        </form>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5' class='text-muted'>No archived records found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Optional: DataTables integration (requires jQuery & DataTables JS/CSS) -->
<script>
    $(document).ready(function() {
        $('#archivedTable').DataTable({
            "order": [[ 2, "desc" ]],
            "columnDefs": [{ "orderable": false, "targets": [3,4] }]
        });
        $('[data-toggle="tooltip"]').tooltip();
    });
</script>
