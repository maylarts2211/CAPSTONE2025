<?php
// Include your layout and config
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');

// Database connection
$host = "localhost";
$user = "root";
$password = "";
$dbname = "sk_bin";
$conn = mysqli_connect($host, $user, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SK Federation List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #2c7be5;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
        }
        .button-container {
            width: 90%;
            margin: 20px auto;
            text-align: left;
        }
        .button-container .btn {
            margin: 5px 0;
        }
    </style>
</head>
<body>

<h2>SK FEDERATION</h2>

<div class="button-container">
    <button class="btn btn-primary" id="addOfficerBtn">
        <i class="fas fa-user-plus"></i> Add Officer
    </button>
</div>

<table>
    <thead>
        <tr>
            <th>Position</th>
            <th>Name</th>
            <th>Barangay</th>
            <th>Term (Start - End)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $query = "SELECT * FROM sk_federation_officers";
        $query_run = mysqli_query($conn, $query);

        if (mysqli_num_rows($query_run) > 0) {
            foreach ($query_run as $officer) {
                echo "<tr>";
                echo "<td><a href='officer_view.php?id=" . urlencode($officer['id']) . "'>" . htmlspecialchars($officer['position']) . "</a></td>";
                echo "<td>" . htmlspecialchars($officer['name']) . "</td>";
                echo "<td>" . htmlspecialchars($officer['barangay']) . "</td>";
                echo "<td>" . htmlspecialchars($officer['term_start']) . " - " . htmlspecialchars($officer['term_end']) . "</td>";
                echo "<td>" . htmlspecialchars($officer['status']) . "</td>";
                echo "<td>";
                echo "<a href='edit_officer.php?id=" . urlencode($officer['id']) . "' class='btn btn-sm btn-warning me-1'><i class='fas fa-edit'></i> Edit</a>";
                echo "<a href='delete_officer.php?id=" . urlencode($officer['id']) . "' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this officer?\");'><i class='fas fa-trash'></i> Delete</a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No federation officers found.</td></tr>";
        }
        ?>
    </tbody>
</table>

<!-- Modal -->
<div class="modal fade" id="addOfficerModal" tabindex="-1" aria-labelledby="addOfficerLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addOfficerLabel">Add Officer</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="modalBodyContent">
        <!-- AJAX-loaded form will go here -->
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('addOfficerBtn').addEventListener('click', function () {
    const modal = new bootstrap.Modal(document.getElementById('addOfficerModal'));
    document.getElementById('modalBodyContent').innerHTML = '<div class="text-center p-3"><i class="fas fa-spinner fa-spin fa-2x"></i> Loading form...</div>';

    fetch('4.php')
        .then(response => response.text())
        .then(html => {
            document.getElementById('modalBodyContent').innerHTML = html;
        })
        .catch(error => {
            document.getElementById('modalBodyContent').innerHTML = '<div class="alert alert-danger">Failed to load form.</div>';
            console.error('Error loading form:', error);
        });

    modal.show();
});
</script>

</body>
</html>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
