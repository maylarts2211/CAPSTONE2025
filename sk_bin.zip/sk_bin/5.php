<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SK Kagawad Registration</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- SB Admin 2 CSS (Minified) -->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
    <!-- Bootstrap 4 (Optional if not included in SB Admin) -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome (Optional for icons) -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

</head>
<body class="bg-gradient-primary">

<div class="container mt-5">
    <div class="card shadow-lg col-lg-8 mx-auto">
        <div class="card-header bg-primary text-white text-center">
            <h3 class="m-0 font-weight-bold">SK Kagawad Registration Form</h3>
        </div>
        <div class="card-body">
            <form id="kagawadForm">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="age">Age</label>
                    <input type="number" name="age" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select name="gender" class="form-control" required>
                        <option value="">--Select--</option>
                        <option>Male</option>
                        <option>Female</option>
                        <option>Other</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea name="address" class="form-control" required></textarea>
                </div>

                <div class="form-group">
                    <label for="contact_number">Contact Number</label>
                    <input type="text" name="contact_number" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="email">Email (optional)</label>
                    <input type="email" name="email" class="form-control">
                </div>

                <div class="form-group">
                    <label for="education">Educational Attainment</label>
                    <input type="text" name="education" class="form-control">
                </div>

                <div class="form-group">
                    <label for="term_start">Term Start</label>
                    <input type="date" name="term_start" class="form-control" required>
                </div>

                <div class="form-group">
                    <label for="term_end">Term End</label>
                    <input type="date" name="term_end" class="form-control" required>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Submit</button>
            </form>

            <div id="response" class="mt-3 text-center font-weight-bold"></div>
        </div>
    </div>
</div>

<!-- JS Scripts (required for SB Admin 2 and Bootstrap) -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/sb-admin-2.min.js"></script>

<!-- AJAX Submission -->
<script>
    document.getElementById("kagawadForm").addEventListener("submit", function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        fetch("submit_kagawad.php", {
            method: "POST",
            body: formData
        })
        .then(response => response.text())
        .then(data => {
            document.getElementById("response").innerText = data;
            this.reset();
        });
    });
</script>

</body>
</html>
