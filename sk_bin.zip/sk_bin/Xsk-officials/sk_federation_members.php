<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "sk_bin";

$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

<?php

include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';
?>



<style>
    .sk-card {
        transition: transform 0.2s, box-shadow 0.7s;
        border-radius: 0.2rem;
        background-color:rgb(10, 22, 39); /* Dark blue */
        border: 3px solid #0b1f61;
        box-shadow: 2px 0 4px rgba(11, 45, 158, 0.4); /* horizontal, vertical, blur, color */
    }
    .sk-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 6px 25px rgba(87, 90, 235, 0.1);
    }
    .sk-card h5 {
        font-weight: 700;
        color:rgb(255, 255, 255);
    }
    .sk-card .card-body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
    }
    .sk-card i {
        font-size: 2rem;
        color:rgb(255, 255, 255);
        margin-bottom: 10px;
    }
    a.text-decoration-none:hover h5 {
        text-decoration: underline;
    }
.btn-sk-add {
    background: linear-gradient(to right, rgb(24, 227, 241), rgb(7, 92, 141)); /* Blue gradient */
    color: #fff !important;
    border: none;
    padding: 10px 20px;
    border-radius: 3px;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    text-decoration: none !important;
    transition: none !important;
}

.btn-sk-add:hover,
.btn-sk-add:focus,
.btn-sk-add:active {
    background: linear-gradient(to right, rgb(24, 227, 241), rgb(7, 92, 141)); /* same as default */
    color: #fff !important;
    text-decoration: none !important;
    box-shadow: none !important;
    outline: none !important;
}



</style>

<div class="d-flex justify-content-end align-items-center px-4 pt-3">
    <a href="add_brgy.php" class="btn-sk-add">
    <i class="fas fa-plus me-1"></i> Add Barangay
    </a>

</div>

<div class="container py-5">
    <div class="row g-4 justify-content-center">
        <?php
        $query = "SELECT * FROM barangay ORDER BY brgy_name ASC";
        $result = mysqli_query($conn, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                $brgy_id = $row['id'];
                $brgy_name = $row['brgy_name'];

                // Link to dynamic barangay view page with id parameter
                $link = "brgy_view.php?id=" . $brgy_id;

                echo "
                <div class='col-sm-6 col-md-4 col-lg-3 mb-4 d-flex'>
                     <a href='{$link}' class='text-decoration-none w-100'>
                        <div class='card sk-card p-3 text-center h-100'>
                            <div class='card-body d-flex flex-column justify-content-center'>
                                <i class='fas fa-user-friends'></i>
                                <h5 class='mt-2'>Brgy. {$brgy_name} SK Officials</h5>
                            </div>
                        </div>
                    </a>
                </div>";
            }
        } else {
            echo "<p class='text-center'>No barangays found.</p>";
        }
        ?>
    </div>
</div>
