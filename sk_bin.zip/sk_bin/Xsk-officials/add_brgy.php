<?php

include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';
?>


<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8 col-lg-6">
            <div class="card shadow-lg rounded-4 border-0">
                <div class="card-header bg-primary text-white text-center rounded-top-4">
                    <h4 class="mb-0"><i class="fas fa-user-plus me-2"></i>Add Barangay</h4>
                </div>
                <div class="card-body p-4">

                    <?php if (isset($_GET['success'])): ?>
                        <div class="alert alert-success">Barangay added successfully!</div>
                    <?php elseif (isset($_GET['error'])): ?>
                        <div class="alert alert-danger">Failed to add Barangay. Please try again.</div>
                    <?php endif; ?>

                    <form action="process_add_brgy.php" method="POST">
                        <div class="mb-3">
                            <label for="barangay_name" class="form-label">Barangay Name</label>
                            <input type="text" class="form-control" id="barangay_name" name="barangay_name" required>
                        </div>

                        <div class="text-end">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save me-1"></i> Save Barangay
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php
include '../includes/scripts.php'; // start HTML, load Bootstrap, etc.
include '../includes/footer.php';

?>