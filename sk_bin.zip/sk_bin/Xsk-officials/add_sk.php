<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "sk_bin";

$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get barangay_id from URL
if (!isset($_GET['barangay_id'])) {
    die("Barangay ID is required.");
}

$barangay_id = intval($_GET['barangay_id']);

// Get barangay name for display
$sql = "SELECT brgy_name FROM barangay WHERE id = $barangay_id";
$result = mysqli_query($conn, $sql);
if (!$result || mysqli_num_rows($result) == 0) {
    die("Barangay not found.");
}

$barangay = mysqli_fetch_assoc($result);
$brgy_name = $barangay['brgy_name'];

// Initialize error and success messages
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $position = trim($_POST['position'] ?? '');
    $term_start = trim($_POST['term_start'] ?? '');
    $term_end = trim($_POST['term_end'] ?? '');

    // Basic validation
    if (empty($name) || empty($position) || empty($term_start) || empty($term_end)) {
        $error = "Please fill in all fields.";
    } else {
        // Use correct table name: tbl_sk_officials
        $sql = "INSERT INTO tbl_sk_officials (barangay_id, name, position, term_start, term_end) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            $error = "Prepare failed: " . $conn->error;
        } else {
            $stmt->bind_param("issss", $barangay_id, $name, $position, $term_start, $term_end);

            if ($stmt->execute()) {
                $success = "SK Official added successfully.";
                $name = $position = $term_start = $term_end = '';
            } else {
                $error = "Execute failed: " . $stmt->error;
            }

            $stmt->close();
        }
    }
}



include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';
?>

<div class="container py-5">
    <h1 class="mb-4">Add SK Official - Brgy. <?php echo htmlspecialchars($brgy_name); ?></h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
    <?php endif; ?>

    <form action="" method="POST" class="w-50">
        <div class="mb-3">
            <label for="name" class="form-label">Full Name</label>
            <input type="text" id="name" name="name" class="form-control" required value="<?php echo htmlspecialchars($name ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="position" class="form-label">Position</label>
            <input type="text" id="position" name="position" class="form-control" required value="<?php echo htmlspecialchars($position ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="term_start" class="form-label">Term Start</label>
            <input type="date" id="term_start" name="term_start" class="form-control" required value="<?php echo htmlspecialchars($term_start ?? ''); ?>">
        </div>

        <div class="mb-3">
            <label for="term_end" class="form-label">Term End</label>
            <input type="date" id="term_end" name="term_end" class="form-control" required value="<?php echo htmlspecialchars($term_end ?? ''); ?>">
        </div>

        <button type="submit" class="btn btn-primary">Add Official</button>
        <a href="brgy_view.php?id=<?php echo $barangay_id; ?>" class="btn btn-secondary ms-2">Cancel</a>
    </form>
</div>

<?php
include '../includes/scripts.php'; // start HTML, load Bootstrap, etc.
include '../includes/footer.php';
?>
