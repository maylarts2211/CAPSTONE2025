<?php

include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';
?>

<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "sk_bin";

$conn = mysqli_connect($host, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Get barangay id from URL
if (!isset($_GET['id'])) {
    die("Barangay ID is required.");
}

$barangay_id = intval($_GET['id']);

// Get barangay info
$sql = "SELECT * FROM barangay WHERE id = $barangay_id";
$result = mysqli_query($conn, $sql);

if (!$result || mysqli_num_rows($result) == 0) {
    die("Barangay not found.");
}

$barangay = mysqli_fetch_assoc($result);
$brgy_name = $barangay['brgy_name'];

// Get SK officials for this barangay from the correct table name
$sql_officials = "SELECT * FROM tbl_sk_officials WHERE barangay_id = $barangay_id ORDER BY position ASC";
$result_officials = mysqli_query($conn, $sql_officials);


?>

<div class="container py-5">

    <div class="d-flex justify-content-end mb-3">
        <!-- Button to add new SK official for this barangay -->
        <a href="add_sk.php?barangay_id=<?php echo $barangay_id; ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i> Add SK Official
        </a>
    </div>

    <h1 class="mb-4">Brgy. <?php echo htmlspecialchars($brgy_name); ?> SK Officials</h1>

    <?php if ($result_officials && mysqli_num_rows($result_officials) > 0): ?>
        <table class="table table-bordered table-striped">
            <thead class="table-primary">
                <tr>
                    <th style="width: 30%;">Name</th>
                    <th style="width: 25%;">Position</th>
                    <th style="width: 20%;">Term Start</th>
                    <th style="width: 25%;">Term End</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($official = mysqli_fetch_assoc($result_officials)): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($official['name']); ?></td>
                        <td><?php echo htmlspecialchars($official['position']); ?></td>
                        <td><?php echo htmlspecialchars($official['term_start']); ?></td>
                        <td><?php echo htmlspecialchars($official['term_end']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No SK officials found for this barangay.</p>
    <?php endif; ?>

    <a href="sk_federation_members.php" class="btn btn-primary mt-4">Back</a>
</div>

<?php
include '../includes/scripts.php'; // start HTML, load Bootstrap, etc.
include '../includes/footer.php';
?>
