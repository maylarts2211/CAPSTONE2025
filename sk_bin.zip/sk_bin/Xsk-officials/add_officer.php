<?php

include '../includes/header.php'; // start HTML, load Bootstrap, etc.
include '../includes/navbar.php';
include '../includes/topbar.php';
?>
<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "<h2>Submitted Youth Profile</h2>";
    echo "Name: " . htmlspecialchars($_POST["last_name"]) . ", " . htmlspecialchars($_POST["first_name"]) . " " . htmlspecialchars($_POST["middle_name"]) . "<br>";
    echo "Age Group: " . htmlspecialchars($_POST["age"]) . "<br>";
    echo "Civil Status: " . htmlspecialchars($_POST["civil_status"]) . "<br>";
    echo "Sex: " . htmlspecialchars($_POST["sex"]) . "<br>";
    echo "Religion: " . htmlspecialchars($_POST["religion"]) . "<br>";
    echo "Contact No.: " . htmlspecialchars($_POST["contact_no"]) . "<br>";
    echo "Email: " . htmlspecialchars($_POST["email"]) . "<br>";
    echo "Registered Voter: " . htmlspecialchars($_POST["registered_voter"]) . "<br>";
    echo "Purok: " . htmlspecialchars($_POST["purok"]) . "<br>";
    echo "Educational Attainment: " . htmlspecialchars($_POST["education"]) . "<br>";
    echo "Course: " . htmlspecialchars($_POST["course"]) . "<br>";
    echo "Status: " . htmlspecialchars($_POST["status"]) . "<br>";
    echo "If out-of-school: " . htmlspecialchars($_POST["out_reason"]) . "<br>";
    echo "Employment: " . htmlspecialchars($_POST["employment"]) . "<br>";
    echo "Duration: " . htmlspecialchars($_POST["duration"]) . "<br>";
    echo "Disability: " . htmlspecialchars($_POST["disability"]) . "<br>";
    echo "Medical Condition: " . htmlspecialchars($_POST["medical"]) . "<br>";
    echo "Youth Org Member: " . htmlspecialchars($_POST["youth_org"]) . "<br>";
    echo "Org Name: " . htmlspecialchars($_POST["org_name"]) . "<br>";
    echo "Skills: " . nl2br(htmlspecialchars($_POST["skills"])) . "<br>";
    echo "Interests: " . nl2br(htmlspecialchars($_POST["interests"])) . "<br>";
    exit;
}
?>




<div>class="container py-5">
    <h2 class="mb-4">SK Profile Form</h2>
    <form method="post">
        <div class="form-row">
            <div class="form-group col-md-4">
                <label>Last Name</label>
                <input type="text" name="last_name" class="form-control">
            </div>
            <div class="form-group col-md-4">
                <label>First Name</label>
                <input type="text" name="first_name" class="form-control">
            </div>
            <div class="form-group col-md-4">
                <label>Middle Name</label>
                <input type="text" name="middle_name" class="form-control">
            </div>
        </div>

        <div class="form-group">
            <label>Age Group</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="age" value="15-17">
                <label class="form-check-label">15-17</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="age" value="18-24">
                <label class="form-check-label">18-24</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="age" value="25-30">
                <label class="form-check-label">25-30</label>
            </div>
        </div>

        <div class="form-group">
            <label>Civil Status</label>
            <select name="civil_status" class="form-control">
                <option>Single</option>
                <option>Married</option>
                <option>Others</option>
            </select>
        </div>

        <div class="form-group">
            <label>Sex</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="sex" value="Male">
                <label class="form-check-label">Male</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="sex" value="Female">
                <label class="form-check-label">Female</label>
            </div>
        </div>

        <div class="form-group">
            <label>Religion</label>
            <input type="text" name="religion" class="form-control">
        </div>

        <div class="form-group">
            <label>Contact No.</label>
            <input type="text" name="contact_no" class="form-control">
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" class="form-control">
        </div>

        <div class="form-group">
            <label>Registered Voter</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="registered_voter" value="Yes">
                <label class="form-check-label">Yes</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="registered_voter" value="No">
                <label class="form-check-label">No</label>
            </div>
        </div>

        <div class="form-group">
            <label>Purok</label>
            <input type="text" name="purok" class="form-control">
        </div>

        <div class="form-group">
            <label>Educational Attainment</label>
            <select name="education" class="form-control">
                <option>Elementary</option>
                <option>Junior HS</option>
                <option>Senior HS</option>
                <option>ALS</option>
                <option>College</option>
                <option>Vocational</option>
                <option>Post-Graduate</option>
                <option>Doctorate</option>
            </select>
        </div>

        <div class="form-group">
            <label>Course</label>
            <input type="text" name="course" class="form-control">
        </div>

        <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control">
                <option>In School</option>
                <option>Out-of-School</option>
                <option>Employed</option>
                <option>Unemployed</option>
            </select>
        </div>

        <div class="form-group">
            <label>If out-of-school, reason</label>
            <input type="text" name="out_reason" class="form-control">
        </div>

        <div class="form-group">
            <label>Employment</label>
            <select name="employment" class="form-control">
                <option>Government</option>
                <option>Private</option>
                <option>Self-employed</option>
            </select>
        </div>

        <div class="form-group">
            <label>Duration</label>
            <input type="text" name="duration" class="form-control">
        </div>

        <div class="form-group">
            <label>Do you have disability/ies?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="disability" value="No">
                <label class="form-check-label">No</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="disability" value="Yes">
                <label class="form-check-label">Yes</label>
            </div>
            <input type="text" name="disability_detail" class="form-control mt-1" placeholder="Specify if Yes">
        </div>

        <div class="form-group">
            <label>Do you have medical condition/s?</label><br>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="medical" value="No">
                <label class="form-check-label">No</label>
            </div>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="radio" name="medical" value="Yes">
                <label class="form-check-label">Yes</label>
            </div>
            <input type="text" name="medical_detail" class="form-control mt-1" placeholder="Specify if Yes">
        </div>

        <div class="form-group">
            <label>Youth Org Member?</label><br>
            <input type="radio" name="youth_org" value="Yes"> Yes
            <input type="radio" name="youth_org" value="No"> No
        </div>

        <div class="form-group">
            <label>Organization Name</label>
            <input type="text" name="org_name" class="form-control">
        </div>

        <div class="form-group">
            <label>Skills</label>
            <textarea name="skills" class="form-control" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label>Interests</label>
            <textarea name="interests" class="form-control" rows="3"></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div> 


include '../includes/scripts.php'; // start HTML, load Bootstrap, etc.
include '../includes/footer.php';

?>