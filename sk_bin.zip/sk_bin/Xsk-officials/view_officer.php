<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "sk_bin");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user ID
$id = $_GET['id'] ?? null;
if (!$id) {
    die("Missing member ID.");
}

// Fetch data
$sql = "SELECT * FROM brgy_amontay WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();

if (!$member) {
    die("Member not found.");
}

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $contact = $_POST['contact_number'];
    $email = $_POST['email'];
    $education = $_POST['education'];
    $term_start = $_POST['term_start'];
    $term_end = $_POST['term_end'];
    $photo = $member['photo']; // default to old photo

    // Photo Upload
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $new_name = uniqid('img_') . '.' . $ext;
        move_uploaded_file($_FILES['photo']['tmp_name'], "uploads/$new_name");
        $photo = "uploads/$new_name";
    }

    $update = $conn->prepare("UPDATE brgy_amontay SET full_name=?, age=?, gender=?, address=?, contact_number=?, email=?, education=?, term_start=?, term_end=?, photo=? WHERE id=?");
    $update->bind_param("sissssssssi", $full_name, $age, $gender, $address, $contact, $email, $education, $term_start, $term_end, $photo, $id);
    $update->execute();

    echo "<script>alert('Updated successfully!'); window.location.href='view_member.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Member</title>

    <!-- SB Admin 2 CSS -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content" class="container mt-4">

            <!-- Page Heading -->
            <h1 class="h3 mb-4 text-gray-800">Edit SK Member</h1>

            <!-- Form Card -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Member Information</h6>
                </div>
                <div class="card-body">
                    <form method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label>Full Name</label>
                            <input type="text" name="full_name" class="form-control" value="<?= htmlspecialchars($member['full_name']) ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Age</label>
                            <input type="number" name="age" class="form-control" value="<?= $member['age'] ?>" required>
                        </div>

                        <div class="form-group">
                            <label>Gender</label>
                            <select name="gender" class="form-control">
                                <option value="Male" <?= $member['gender'] == 'Male' ? 'selected' : '' ?>>Male</option>
                                <option value="Female" <?= $member['gender'] == 'Female' ? 'selected' : '' ?>>Female</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Address</label>
                            <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($member['address']) ?>">
                        </div>

                        <div class="form-group">
                            <label>Contact Number</label>
                            <input type="text" name="contact_number" class="form-control" value="<?= $member['contact_number'] ?>">
                        </div>

                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" name="email" class="form-control" value="<?= $member['email'] ?>">
                        </div>

                        <div class="form-group">
                            <label>Education</label>
                            <input type="text" name="education" class="form-control" value="<?= $member['education'] ?>">
                        </div>

                        <div class="form-group">
                            <label>Term Start</label>
                            <input type="date" name="term_start" class="form-control" value="<?= $member['term_start'] ?>">
                        </div>

                        <div class="form-group">
                            <label>Term End</label>
                            <input type="date" name="term_end" class="form-control" value="<?= $member['term_end'] ?>">
                        </div>

                        <div class="form-group">
                            <label>Profile Photo</label><br>
                            <?php if (!empty($member['photo'])): ?>
                                <img src="<?= $member['photo'] ?>" alt="Profile" style="height: 100px;"><br><br>
                            <?php endif; ?>
                            <input type="file" name="photo" class="form-control-file">
                        </div>

                        <button type="submit" class="btn btn-success">Update</button>
                        <a href="view_member.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>

        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Bootstrap and SB Admin 2 JS -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="js/sb-admin-2.min.js"></script>
</body>
</html>
