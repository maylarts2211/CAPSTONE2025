<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
 ?>
<section id="financial-reports" style="font-family: Arial, sans-serif; padding: 30px; background-color: #f7f7f7;">
  <h2 style="font-size: 28px; margin-bottom: 20px;">Financial Reports</h2>
  <p style="margin-bottom: 30px;"></p>

  <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px;">
    
    <!-- Card 1 -->
    <a href="budget-allocations.html" style="text-decoration: none; color: inherit;">
      <div style="background-color: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); transition: transform 0.2s;">
        <i class="fas fa-coins" style="font-size: 30px; color: #007BFF;"></i>
        <h3 style="font-size: 20px; margin-top: 10px;">Budget Allocations</h3>
        <p style="margin-top: 10px;">View detailed submitted budgets per barangay, including proposed programs and approved fund distributions.</p>
        <p style="margin-top: 10px; font-weight: bold; color: #007BFF;">See more →</p>
      </div>
    </a>

    <!-- Card 2 -->
    <a href="expense-summary.html" style="text-decoration: none; color: inherit;">
      <div style="background-color: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); transition: transform 0.2s;">
        <i class="fas fa-file-invoice-dollar" style="font-size: 30px; color: #007BFF;"></i>
        <h3 style="font-size: 20px; margin-top: 10px;">Expense Summaries</h3>
        <p style="margin-top: 10px;">Breakdown of actual expenses per project, including remaining balances and fund re-allocations.</p>
        <p style="margin-top: 10px; font-weight: bold; color: #007BFF;">See more →</p>
      </div>
    </a>

    <!-- Card 3 -->
    <a href="downloads.html" style="text-decoration: none; color: inherit;">
      <div style="background-color: white; border-radius: 12px; padding: 20px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); transition: transform 0.2s;">
        <i class="fas fa-file-download" style="font-size: 30px; color: #007BFF;"></i>
        <h3 style="font-size: 20px; margin-top: 10px;">Payroll Management </h3>
        <p style="margin-top: 10px;">Breakdown of actual expenses per project, including remaining balances and fund re-allocations.</p>
        <p style="margin-top: 10px; font-weight: bold; color: #007BFF;">See more →</p>
      </div>
    </a>

  </div>
</section>




<?php
include('includes/scripts.php');
include('includes/footer.php');
?>