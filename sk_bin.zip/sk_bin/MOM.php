<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');

$conn = new mysqli("localhost", "root", "", "sk_bin");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ===================
// UPDATE MOM
// ===================
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_submit'])) {
    $mom_id = $_POST['mom_id'];
    $mom_title = $_POST['meeting_type'];
    $mom_datetime = $_POST['meeting_datetime'];
    $mom_location = $_POST['location'];
    $mom_presiding_officer = $_POST['presiding_officer'];
    $mom_secretary = $_POST['secretary'];
    $mom_attendees_count = (int)$_POST['present_count'];
    $mom_agenda_summary = $_POST['agenda_summary'];
    $mom_agenda_1 = $_POST['agenda_1'];
    $mom_agenda_2 = $_POST['agenda_2'];
    $mom_agenda_3 = $_POST['agenda_3'];
    $mom_agenda_4 = $_POST['agenda_4'];
    $mom_other_matters = $_POST['other_matters'];
    $mom_adjournment = $_POST['adjournment'];
    $mom_attachment = '';

    if (!empty($_FILES['file_attachment']['name'])) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $filename = basename($_FILES['file_attachment']['name']);
        $safe_filename = preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $filename);
        $target_file = $upload_dir . time() . '_' . $safe_filename;
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['file_attachment']['tmp_name'], $target_file)) {
                $mom_attachment = basename($target_file);
            } else {
                echo "<script>alert('Failed to upload file.');</script>";
            }
        } else {
            echo "<script>alert('Invalid file type.');</script>";
        }
    } else {
        $query = $conn->prepare("SELECT mom_attachment FROM tbl_mom WHERE mom_id = ?");
        $query->bind_param("i", $mom_id);
        $query->execute();
        $query->bind_result($existing_attachment);
        $query->fetch();
        $query->close();
        $mom_attachment = $existing_attachment;
    }

    $stmt = $conn->prepare("UPDATE tbl_mom SET 
        mom_title = ?, mom_datetime = ?, mom_location = ?, mom_presiding_officer = ?, mom_secretary = ?, 
        mom_attendees_count = ?, mom_agenda_summary = ?, mom_agenda_1 = ?, mom_agenda_2 = ?, mom_agenda_3 = ?, 
        mom_agenda_4 = ?, mom_other_matters = ?, mom_adjournment = ?, mom_attachment = ? 
        WHERE mom_id = ?");

    $stmt->bind_param("sssssissssssssi", 
        $mom_title, $mom_datetime, $mom_location, $mom_presiding_officer, $mom_secretary,
        $mom_attendees_count, $mom_agenda_summary, $mom_agenda_1, $mom_agenda_2, $mom_agenda_3,
        $mom_agenda_4, $mom_other_matters, $mom_adjournment, $mom_attachment, $mom_id);

    if ($stmt->execute()) {
        echo "<script>alert('Minutes of Meeting updated successfully.'); window.location.href='MOM.php';</script>";
    } else {
        echo "<script>alert('Error updating record.');</script>";
    }

    $stmt->close();
    exit();
}
// ===================
// INSERT MOM
// ===================
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $meeting_type = $_POST['meeting_type'];
    $meeting_datetime = $_POST['meeting_datetime'];
    $location = $_POST['location'];
    $presiding_officer = $_POST['presiding_officer'];
    $secretary = $_POST['secretary'];
    $present_count = (int)$_POST['present_count'];
    $agenda_summary = $_POST['agenda_summary'];
    $agenda_1 = $_POST['agenda_1'];
    $agenda_2 = $_POST['agenda_2'];
    $agenda_3 = $_POST['agenda_3'];
    $agenda_4 = $_POST['agenda_4'];
    $other_matters = $_POST['other_matters'];
    $adjournment = $_POST['adjournment'];
    $attachment = '';

    if (!empty($_FILES['file_attachment']['name'])) {
        $upload_dir = 'uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $file_name = basename($_FILES['file_attachment']['name']);
        $target_file = $upload_dir . time() . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $file_name);
        $file_type = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $allowed_types = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];

        if (in_array($file_type, $allowed_types)) {
            if (move_uploaded_file($_FILES['file_attachment']['tmp_name'], $target_file)) {
                $attachment = basename($target_file);
            } else {
                echo "<script>alert('Error uploading the file.');</script>";
            }
        } else {
            echo "<script>alert('Invalid file type. Allowed: pdf, doc, docx, jpg, jpeg, png');</script>";
        }
    }

    $stmt = $conn->prepare("INSERT INTO tbl_mom 
        (mom_title, mom_datetime, mom_location, mom_presiding_officer, mom_secretary, mom_attendees_count, mom_agenda_summary, mom_agenda_1, mom_agenda_2, mom_agenda_3, mom_agenda_4, mom_other_matters, mom_adjournment, mom_attachment) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssissssssss", 
        $meeting_type, $meeting_datetime, $location, $presiding_officer, $secretary, $present_count, 
        $agenda_summary, $agenda_1, $agenda_2, $agenda_3, $agenda_4, $other_matters, $adjournment, $attachment);

    if ($stmt->execute()) {
        echo "<script>alert('Minutes of Meeting added successfully!');</script>";
    } else {
        echo "<script>alert('Failed to add Minutes of Meeting.');</script>";
    }
    $stmt->close();
}
?>



<div class="container-fluid mb-0">

 <div class="card-body py-1 px-0 border-bottom d-flex justify-content-between align-items-center flex-wrap">

  <!-- Left: Navigation Links -->
  <div class="d-flex gap-1 flex-wrap align-items-center">
    <a href="MOM.php" class="btn btn-sm btn-primary fw-semibold rounded-pill px-4 py-2 shadow-sm">
      MOM
    </a>
    <a href="liquidation_report.php" class="btn btn-sm btn-outline-primary rounded-pill px-4 py-2">
      Schedule Meeting
    </a>
    <a href="liquidation_report.php" class="btn btn-sm btn-outline-primary rounded-pill px-4 py-2">
      Resolution
    </a>
    <a href="forms.php" class="btn btn-sm btn-outline-primary rounded-pill px-4 py-2">
      Forms
    </a>
  </div>

  <!-- Right: Action Buttons -->
  <div class="d-flex gap-1 mt-3 mt-md-0">
    <button class="btn btn-sm btn-success rounded-pill px-4 py-2 shadow-sm" data-toggle="modal" data-target="#addMinutesModal">
      <i class="fas fa-plus me-1"></i> Add
    </button>
    <button class="btn btn-sm btn-secondary rounded-pill px-4 py-2" onclick="window.location.href='MOM_archive.php';">
      <i class="fas fa-archive me-1"></i> Archive
    </button>
  </div>

</div>


<!-- Add Minutes Modal -->
<div class="modal fade" id="addMinutesModal" tabindex="-1" role="dialog" aria-labelledby="addMinutesModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
    <div class="modal-content" style="max-height: 90vh; overflow-y: auto;">
      <form method="POST" enctype="multipart/form-data">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Add Minutes of Meeting</h5>
          <button type="button" class="btn-close btn-close-white" data-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body py-3" style="max-height: 70vh; overflow-y: auto;">
          <div class="row gx-4">
            <!-- Left Column -->
            <div class="col-md-6">
              <?php
              $leftFields = [
                ['label' => 'Meeting Type', 'name' => 'meeting_type', 'type' => 'text', 'placeholder' => 'e.g., Regular Monthly Meeting', 'required' => true],
                ['label' => 'Date & Time', 'name' => 'meeting_datetime', 'type' => 'datetime-local', 'required' => true],
                ['label' => 'Location', 'name' => 'location', 'type' => 'text', 'required' => true],
                ['label' => 'Presiding Officer', 'name' => 'presiding_officer', 'type' => 'text', 'required' => true],
                ['label' => 'Secretary', 'name' => 'secretary', 'type' => 'text', 'required' => true],
                ['label' => 'No. of Attendees', 'name' => 'present_count', 'type' => 'number', 'min' => 1, 'required' => true],
              ];
              foreach ($leftFields as $field) {
                echo "<div class='mb-3'>";
                echo "<label class='form-label'>{$field['label']}</label>";
                echo "<input type='{$field['type']}' name='{$field['name']}' class='form-control form-control-sm'" . 
                    (isset($field['placeholder']) ? " placeholder='{$field['placeholder']}'" : "") .
                    (isset($field['min']) ? " min='{$field['min']}'" : "") .
                    ($field['required'] ? " required" : "") . ">";
                echo "</div>";
              }
              ?>
              <div class="mb-3">
                <label class="form-label">Attachment (optional)</label>
                <input type="file" name="file_attachment" multiple class="form-control form-control-sm" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
              </div>
            </div>

            <!-- Right Column -->
            <div class="col-md-6">
              <?php
              $rightFields = [
                ['label' => 'Agenda Summary', 'name' => 'agenda_summary'],
                ['label' => 'Agenda 1', 'name' => 'agenda_1'],
                ['label' => 'Agenda 2', 'name' => 'agenda_2'],
                ['label' => 'Agenda 3', 'name' => 'agenda_3'],
                ['label' => 'Agenda 4', 'name' => 'agenda_4'],
                ['label' => 'Other Matters', 'name' => 'other_matters'],
              ];
              foreach ($rightFields as $field) {
                echo "<div class='mb-3'>";
                echo "<label class='form-label'>{$field['label']}</label>";
                echo "<textarea name='{$field['name']}' class='form-control form-control-sm' rows='2'></textarea>";
                echo "</div>";
              }
              ?>
              <div class="mb-3">
                <label class="form-label">Adjournment Details</label>
                <input type="text" name="adjournment" class="form-control form-control-sm">
              </div>
            </div>
          </div>
        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-success btn-sm px-4">Save</button>
          <button type="button" class="btn btn-secondary btn-sm px-4" data-dismiss="modal">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- View Table -->
<div class="container-fluid px-0">
  <div class="card shadow-sm mb-4">
    <div class="card-header py-2 bg-primarytext-white rounded-top">
     
    </div>
    <div class="card-body p-2">
      <div class="table-responsive">
        <table class="table table-bordered table-hover table-striped table-sm align-middle" id="minutesTable" style="position: relative;">
          <thead class="table-light sticky-top">
            <tr>
              <th>ID</th>
              <th>Meeting Type</th>
              <th>Date &amp; Time</th>
              <th>Attachment</th>
              <th class="text-center">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $query = "SELECT * FROM tbl_mom WHERE mom_archived = 0 ORDER BY mom_datetime DESC";
            $result = $conn->query($query);
            while ($row = $result->fetch_assoc()) {
              $data_json = htmlspecialchars(json_encode($row), ENT_QUOTES, 'UTF-8');
              $formatted_date = date("M d, Y h:i A", strtotime($row['mom_datetime']));
              $file = $row['mom_attachment'] 
                ? "<a href='uploads/{$row['mom_attachment']}' class='badge bg-success text-decoration-none' target='_blank'><i class='fas fa-file-alt'></i> View</a>" 
                : "<span class='text-muted'>None</span>";

              echo "<tr data-minutes='{$data_json}'>
                      <td>{$row['mom_id']}</td>
                      <td>" . htmlspecialchars($row['mom_title']) . "</td>
                      <td>{$formatted_date}</td>
                      <td>{$file}</td>
                      <td class='text-center'>
                        <button class='btn btn-info btn-sm me-1 view-details' title='View Details'><i class='fas fa-eye'></i></button>
                        <button class='btn btn-warning btn-sm me-1 edit-btn' data-id='{$row['mom_id']}' title='Edit'><i class='fas fa-edit'></i></button>
                        <button class='btn btn-danger btn-sm archive-btn' data-id='{$row['mom_id']}' title='Archive'><i class='fas fa-archive'></i></button>
                      </td>
                    </tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>


<!-- See More Modal -->
<div class="modal fade" id="seeMoreModal" tabindex="-1" role="dialog" aria-labelledby="seeMoreModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-secondary text-white">
                <h5 class="modal-title" id="seeMoreModalLabel">Minutes Details</h5>
                <div class="ml-auto d-flex">
                    <button type="button" class="btn btn-light btn-sm mr-2" onclick="printModalContent()">
                        <i class="fa fa-print"></i> Print
                    </button>
                    <button type="button" class="close text-white" data-dismiss="modal">&times;</button>
                </div>
            </div>
            <div class="modal-body" id="modalContent"></div>
        </div>
    </div>
</div>

<!-- Edit Minutes Modal -->
<div class="modal fade" id="editMinutesModal" tabindex="-1" role="dialog" aria-labelledby="editMinutesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content" style="max-height: 90vh; overflow-y: auto;">
            <form method="POST" enctype="multipart/form-data" id="editMinutesForm">
                <input type="hidden" name="mom_id" id="edit_mom_id">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title">Edit Minutes of Meeting</h5>
                    <button type="button" class="close text-dark" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body" style="max-height: 70vh; overflow-y: auto;">
                    <div class="row">
                        <!-- Left Column -->
                        <div class="col-md-6">
                            <?php
                            // Reuse $leftFields array from Add modal
                            foreach ($leftFields as $field) {
                                echo "<div class='form-group'>";
                                echo "<label>{$field['label']}</label>";
                                echo "<input type='{$field['type']}' name='{$field['name']}' id='edit_{$field['name']}' class='form-control'" . 
                                    (isset($field['placeholder']) ? " placeholder='{$field['placeholder']}'" : "") .
                                    (isset($field['min']) ? " min='{$field['min']}'" : "") .
                                    ($field['required'] ? " required" : "") . ">";
                                echo "</div>";
                            }
                            ?>
                            <div class="form-group">
                                <label>Attachment (optional)</label>
                                <input type="file" name="file_attachment" class="form-control-file" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                                <small id="currentAttachment"></small>
                            </div>
                        </div>

                        <!-- Right Column -->
                        <div class="col-md-6">
                            <?php
                            foreach ($rightFields as $field) {
                                echo "<div class='form-group'>";
                                echo "<label>{$field['label']}</label>";
                                echo "<textarea name='{$field['name']}' id='edit_{$field['name']}' class='form-control' rows='2'></textarea>";
                                echo "</div>";
                            }
                            ?>
                            <div class="form-group">
                                <label>Adjournment Details</label>
                                <input type="text" name="adjournment" id="edit_adjournment" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="submit" name="edit_submit" class="btn btn-warning">Update</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    document.querySelectorAll('.edit-btn').forEach(button => {
    button.addEventListener('click', function () {
        const row = this.closest('tr');
        const data = JSON.parse(row.getAttribute('data-minutes'));

        // Fill input fields in edit modal
        document.getElementById('edit_mom_id').value = data.mom_id;
        document.getElementById('edit_meeting_type').value = data.mom_title;
        document.getElementById('edit_meeting_datetime').value = data.mom_datetime;
        document.getElementById('edit_location').value = data.mom_location;
        document.getElementById('edit_presiding_officer').value = data.mom_presiding_officer;
        document.getElementById('edit_secretary').value = data.mom_secretary;
        document.getElementById('edit_present_count').value = data.mom_attendees_count;

        document.getElementById('edit_agenda_summary').value = data.mom_agenda_summary;
        document.getElementById('edit_agenda_1').value = data.mom_agenda_1;
        document.getElementById('edit_agenda_2').value = data.mom_agenda_2;
        document.getElementById('edit_agenda_3').value = data.mom_agenda_3;
        document.getElementById('edit_agenda_4').value = data.mom_agenda_4;
        document.getElementById('edit_other_matters').value = data.mom_other_matters;
        document.getElementById('edit_adjournment').value = data.mom_adjournment;

        // Show current attachment if exists
        const currentAttachment = data.mom_attachment 
            ? `<a href='uploads/${data.mom_attachment}' target='_blank'>Current file</a>` 
            : 'No current attachment.';
        document.getElementById('currentAttachment').innerHTML = currentAttachment;

        // Show the modal
        $('#editMinutesModal').modal('show');
    });
});

</script>

<script>
    // JavaScript for viewing details in modal (optional based on your logic)
    document.querySelectorAll('.view-details').forEach(button => {
        button.addEventListener('click', function () {
            const row = this.closest('tr');
            const data = JSON.parse(row.getAttribute('data-minutes'));
            let html = `<strong>Meeting Type:</strong> ${data.mom_title}<br>
                        <strong>Date & Time:</strong> ${new Date(data.mom_datetime).toLocaleString()}<br>
                        <strong>Location:</strong> ${data.mom_location}<br>
                        <strong>Presiding Officer:</strong> ${data.mom_presiding_officer}<br>
                        <strong>Secretary:</strong> ${data.mom_secretary}<br>
                        <strong>No. of Attendees:</strong> ${data.mom_attendees_count}<br>
                        <strong>Agenda Summary:</strong> ${data.mom_agenda_summary}<br>
                        <strong>Agenda 1:</strong> ${data.mom_agenda_1}<br>
                        <strong>Agenda 2:</strong> ${data.mom_agenda_2}<br>
                        <strong>Agenda 3:</strong> ${data.mom_agenda_3}<br>
                        <strong>Agenda 4:</strong> ${data.mom_agenda_4}<br>
                        <strong>Other Matters:</strong> ${data.mom_other_matters}<br>
                        <strong>Adjournment:</strong> ${data.mom_adjournment}`;
            document.getElementById('modalContent').innerHTML = html;
            $('#seeMoreModal').modal('show');
        });
    });
    // Print Function
    function printModalContent() {
        const content = document.getElementById('modalContent').innerHTML;
        const printWindow = window.open('', '', 'width=800,height=600');
        printWindow.document.write(`
            <html>
            <head>
                <title>Print Minutes</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    h1 { text-align: center; }
                    strong { display: inline-block; width: 150px; }
                    br { margin-bottom: 10px; }
                </style>
            </head>
            <body>
                <h1>Minutes of the Meeting</h1>
                ${content}
            </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
        printWindow.close();
    }
</script>



<script>
document.querySelectorAll('.archive-btn').forEach(button => {
    button.addEventListener('click', function () {
        const momId = this.getAttribute('data-id');
        if (confirm('Are you sure you want to archive this record?')) {
            fetch('MOM_archive.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'archive_id=' + momId
            })
            .then(response => response.text())
            .then(data => {
                alert('Archived successfully!');
                location.reload();
            })
            .catch(error => {
                alert('Failed to archive.');
                console.error(error);
            });
        }
    });
});
</script>
<script>
  $(document).ready(function () {
    $('#minutesTable').DataTable({
      "lengthMenu": [5, 10, 15, 20], // Options for row count
      "pageLength": 10,              // Default rows shown
      "language": {
        "search": "Filter records:" // Optional: Customize search label
      },
      "columnDefs": [
        { "orderable": false, "targets": 4 } // Disable sorting for Action column
      ]
    });
  });
</script>
