<?php
// Database connection settings
$host = "localhost";          // Change if needed
$db_user = "root";
$db_pass = "";
$db_name = "sk_bin";

// Email content
$subject = "📢 Important Announcement from Our Team";
$message = "Hello!\n\nWe have an exciting update just for our Gmail users.\n\nStay tuned for more!\n\n- Your Team";
$headers = "From: no-reply@yourdomain.com"; // Use your actual domain for best deliverability

// Connect to MySQL
$conn = new mysqli($host, $db_user, $db_pass, $db_name);

// Check connection
if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}

// Query Gmail users
$sql = "SELECT email FROM users WHERE email LIKE '%@gmail.com'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "📬 Sending announcement to Gmail users...<br><br>";

    while ($row = $result->fetch_assoc()) {
        $email = $row["email"];
        if (mail($email, $subject, $message, $headers)) {
            echo "✅ Email sent to: $email<br>";
        } else {
            echo "❌ Failed to send to: $email<br>";
        }

        // Optional: sleep(1); // Uncomment if you want to slow down sending
    }

    echo "<br>🎉 Done sending!";
} else {
    echo "ℹ️ No Gmail users found.";
}

// Close connection
$conn->close();
?>
