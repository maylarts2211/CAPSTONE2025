-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2025 at 03:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sk_bin`
--

-- --------------------------------------------------------

--
-- Table structure for table `barangay`
--

CREATE TABLE `barangay` (
  `id` int(11) NOT NULL,
  `brgy_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barangay`
--

INSERT INTO `barangay` (`id`, `brgy_name`, `created_at`) VALUES
(1, 'Amontay', '2025-05-04 18:18:32'),
(2, 'Bagroy', '2025-05-04 18:18:32'),
(3, 'Bi-ao', '2025-05-04 18:19:13'),
(4, 'Canmoros', '2025-05-04 18:19:13'),
(5, 'Enclaro', '2025-05-04 18:19:56'),
(6, 'Marina', '2025-05-04 18:19:56'),
(7, 'Pagla-um', '2025-05-04 18:20:33'),
(8, 'Payao', '2025-05-04 18:20:33'),
(9, 'Progreso', '2025-05-04 18:21:14'),
(10, 'San Jose', '2025-05-04 18:21:14'),
(11, 'San Juan', '2025-05-04 18:21:46'),
(12, 'San Pedro', '2025-05-04 18:21:46'),
(13, 'San Teodoro', '2025-05-04 18:22:35'),
(14, 'San Vicente', '2025-05-04 18:22:35'),
(15, 'Santo Rosario', '2025-05-04 18:23:31'),
(16, 'Santol', '2025-05-04 18:23:31');

-- --------------------------------------------------------

--
-- Table structure for table `sk_feedback`
--

CREATE TABLE `sk_feedback` (
  `id` int(11) NOT NULL,
  `gmail` varchar(100) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `barangay_id` int(11) NOT NULL,
  `category` enum('Comment','Suggestion','Complaint','Praise') NOT NULL,
  `message` text NOT NULL,
  `date_submitted` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sk_feedback`
--

INSERT INTO `sk_feedback` (`id`, `gmail`, `full_name`, `barangay_id`, `category`, `message`, `date_submitted`) VALUES
(1, 'mayla@gmail.com', 'Mayla Bayona', 5, 'Comment', 'HAHAHAHAHA', '2025-05-28 16:10:54'),
(2, 'negneg@gmail.com', 'negneg', 9, 'Suggestion', 'doiijspof', '2025-05-28 16:57:15'),
(3, 'HAHAH@GMAIL.COM', 'AHHHAA', 12, 'Comment', 'ASASASASA', '2025-05-28 17:00:02');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$jhlOn75S1hlPAd2NH/FTOu.AM7CWQKl21d//R6e3o.1Ec9zqZWpMu');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cop`
--

CREATE TABLE `tbl_cop` (
  `cop_id` int(11) NOT NULL,
  `cop_name` varchar(255) NOT NULL,
  `cop_description` text DEFAULT NULL,
  `cop_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_archived` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_cop`
--

INSERT INTO `tbl_cop` (`cop_id`, `cop_name`, `cop_description`, `cop_created_at`, `is_archived`) VALUES
(1, 'Health', 'hahaha', '2025-05-28 21:57:42', 0),
(2, 'Health', 'focuses on promoting the physical, mental, and emotional well-being of youth in the barangay...', '2025-05-28 22:01:21', 0),
(3, 'Health', 'focuses on promoting the physical, mental, and emotional well-being of youth in the barangay...', '2025-05-28 22:04:20', 0),
(4, 'Education', 'Aiming to promote equitable access to quality education and support youth in acquiring knowledge, skills, and values necessary for future success.', '2025-05-28 22:39:06', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mom`
--

CREATE TABLE `tbl_mom` (
  `mom_id` int(11) NOT NULL,
  `mom_title` varchar(255) NOT NULL,
  `mom_datetime` datetime NOT NULL,
  `mom_location` varchar(255) NOT NULL,
  `mom_presiding_officer` varchar(100) NOT NULL,
  `mom_secretary` varchar(100) NOT NULL,
  `mom_attendees_count` int(11) NOT NULL,
  `mom_agenda_summary` text NOT NULL,
  `mom_agenda_1` text NOT NULL,
  `mom_agenda_2` text DEFAULT NULL,
  `mom_agenda_3` text DEFAULT NULL,
  `mom_agenda_4` text DEFAULT NULL,
  `mom_other_matters` text DEFAULT NULL,
  `mom_adjournment` varchar(255) DEFAULT NULL,
  `mom_attachment` text DEFAULT NULL,
  `mom_created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `mom_archived` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_mom`
--

INSERT INTO `tbl_mom` (`mom_id`, `mom_title`, `mom_datetime`, `mom_location`, `mom_presiding_officer`, `mom_secretary`, `mom_attendees_count`, `mom_agenda_summary`, `mom_agenda_1`, `mom_agenda_2`, `mom_agenda_3`, `mom_agenda_4`, `mom_other_matters`, `mom_adjournment`, `mom_attachment`, `mom_created_at`, `mom_archived`) VALUES
(1, 'Incoming Youth activities', '2025-05-21 21:17:00', 'Brgy. biao', 'Jessica', 'Mayla', 5, 'chuchu', 'ddjd', 'dsf', 'dfds', 'sdfd', 'sdfd', '', '', '2025-05-22 05:18:37', 1),
(2, 'Incoming Youth activities', '2025-05-21 21:17:00', 'Brgy. biao', 'Jessica', 'Mayla', 5, 'chuchu', 'ddjd', 'dsf', 'dfds', 'sdfd', 'sdfd', '', '', '2025-05-22 05:29:53', 0),
(3, 'Incoming Youth activities', '2025-05-21 21:17:00', 'Brgy. biao', 'Jessica', 'Mayla', 5, 'chuchu', 'ddjd', 'dsf', 'dfds', 'sdfd', 'sdfd', '', '', '2025-05-22 05:30:24', 1),
(4, 'Incoming Youth activities', '2025-05-21 21:17:00', 'Brgy. biao', 'Jessica', 'Mayla', 5, 'chuchu', 'ddjd', 'dsf', 'dfds', 'sdfd', 'sdfd', '', '', '2025-05-22 05:30:37', 0),
(5, 'Incoming Youth activities', '2025-05-21 21:17:00', 'Brgy. biao', 'Jessica', 'Mayla', 5, 'chuchu', 'ddjd', 'dsf', 'dfds', 'sdfd', 'sdfd', '', '', '2025-05-22 05:33:46', 1),
(6, 'Incoming Youth activities', '2025-05-21 21:17:00', 'Brgy. biao', 'Jessica', 'Mayla', 5, 'chuchu', 'ddjd', 'dsf', 'dfds', 'sdfd', 'sdfd', '', '', '2025-05-22 05:44:36', 0),
(7, 'asa', '2025-05-21 19:39:00', 'sas', 'sas', 'as', 1, 'saa', 'asa', 'sasas', 'sas', 'asaa', 'sasasa', 'sas', '', '2025-05-24 03:43:40', 1),
(8, 'jjessica', '2025-05-24 11:22:00', 'ss', 'ss', 'ss', 2, 'aj', 'anaj', 'jdsk', 'djsdjk', 'jds', 'kjdsk', 'ksdjskdjs', '', '2025-05-24 19:20:46', 0),
(9, 'jjessica update 2', '2025-05-25 11:22:00', 'ss', 'ss', 'ss', 2, 'aj', 'anaj', 'jdsk', 'djsdjk', 'jds', 'kjdsk', 'ksdjskdjs', '1748121144_0_image_ella__1_.png', '2025-05-25 05:32:44', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_officials`
--

CREATE TABLE `tbl_officials` (
  `officials_id` int(11) NOT NULL,
  `officials_f_name` varchar(100) NOT NULL,
  `officials_l_name` varchar(100) NOT NULL,
  `officials_suffix` varchar(50) DEFAULT NULL,
  `officials_position` varchar(100) NOT NULL,
  `official_province` varchar(100) NOT NULL,
  `official_city_municipal` varchar(100) NOT NULL,
  `officials_barangay` varchar(100) NOT NULL,
  `officials_term_start` year(4) NOT NULL,
  `officials_term_end` year(4) NOT NULL,
  `officials_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_officials`
--

INSERT INTO `tbl_officials` (`officials_id`, `officials_f_name`, `officials_l_name`, `officials_suffix`, `officials_position`, `official_province`, `official_city_municipal`, `officials_barangay`, `officials_term_start`, `officials_term_end`, `officials_status`) VALUES
(1, 'Jessica', 'Laguidao', NULL, 'SK Secretary', 'Negros, Occidental', 'Binalbagan', 'Enclaro', '2026', '2028', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `youth`
--

CREATE TABLE `youth` (
  `id` int(11) NOT NULL,
  `youth_number` varchar(50) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `contact_number` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barangay`
--
ALTER TABLE `barangay`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sk_feedback`
--
ALTER TABLE `sk_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `barangay_id` (`barangay_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `tbl_cop`
--
ALTER TABLE `tbl_cop`
  ADD PRIMARY KEY (`cop_id`);

--
-- Indexes for table `tbl_mom`
--
ALTER TABLE `tbl_mom`
  ADD PRIMARY KEY (`mom_id`);

--
-- Indexes for table `tbl_officials`
--
ALTER TABLE `tbl_officials`
  ADD PRIMARY KEY (`officials_id`);

--
-- Indexes for table `youth`
--
ALTER TABLE `youth`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `youth_number` (`youth_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barangay`
--
ALTER TABLE `barangay`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `sk_feedback`
--
ALTER TABLE `sk_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_cop`
--
ALTER TABLE `tbl_cop`
  MODIFY `cop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_mom`
--
ALTER TABLE `tbl_mom`
  MODIFY `mom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_officials`
--
ALTER TABLE `tbl_officials`
  MODIFY `officials_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `youth`
--
ALTER TABLE `youth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sk_feedback`
--
ALTER TABLE `sk_feedback`
  ADD CONSTRAINT `sk_feedback_ibfk_1` FOREIGN KEY (`barangay_id`) REFERENCES `barangay` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
