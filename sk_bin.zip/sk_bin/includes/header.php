<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>SK Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="/sk_bin/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- SB Admin 2 CSS -->
    <link href="/sk_bin/css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Bootstrap (pick one version only) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- DataTables -->
    <link href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap4.min.css" rel="stylesheet">




  <link rel="stylesheet" href="../includes/custom-style.css">


    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- jQuery, Bootstrap JS, DataTables -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap4.min.js"></script>
</head>

<body id="page-top" class="custom-background">


    <!-- Page Wrapper -->
    <div id="wrapper">
