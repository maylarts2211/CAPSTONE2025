<?php
// Database credentials
$host = 'localhost';  // Update with your database host
$dbname = 'sk_bin';   // Your database name
$username = 'root';   // Your database username
$password = '';       // Your database password

// Create a PDO instance for MySQL database connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());


}
?>
<?php
define('ROOT_PATH', dirname(__DIR__)); // goes one directory up
define('INCLUDES_PATH', ROOT_PATH . '/includes');
?>

