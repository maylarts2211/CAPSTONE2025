<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/config.php');  // This sets $conn

$response = ['success' => false, 'message' => ''];

function generateYouthNumber() {
    return 'YN-' . str_pad(mt_rand(1, 999999), 6, '0', STR_PAD_LEFT);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $_POST['fullname'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $contactNumber = $_POST['contactNumber'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $barangay = $_POST['barangay'];
    $expiryDate = $_POST['expiry_date'];

    $youthNumber = generateYouthNumber();

    $insertQuery = "INSERT INTO youth 
        (youth_number, fullname, dob, gender, contact_number, email, address, barangay, expiry_date, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";

    $stmt = $config->prepare($insertQuery);
    if ($stmt === false) {
        $response['message'] = 'Prepare failed: ' . htmlspecialchars($config->error);
    } else {
        $stmt->bind_param("sssssssss", $youthNumber, $fullname, $dob, $gender, $contactNumber, $email, $address, $barangay, $expiryDate);

        if ($stmt->execute()) {
            $response['success'] = true;
            $response['message'] = 'Youth member added successfully! <strong>Youth Number:</strong> ' . htmlspecialchars($youthNumber);
        } else {
            $response['message'] = 'Error: ' . htmlspecialchars($stmt->error);
        }
        $stmt->close();
    }
}
?>

<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">

      <?php if ($response['success']): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <strong><i class="fas fa-check-circle"></i> Success!</strong> <?php echo $response['message']; ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php elseif (!empty($response['message'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <strong><i class="fas fa-times-circle"></i> Error!</strong> <?php echo $response['message']; ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>

      <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
          <h5 class="mb-0"><i class="fas fa-user-plus"></i> Add Youth Member</h5>
        </div>
        <form method="post" action="">
          <div class="card-body">
            <div class="row mb-3">
              <div class="col-md-6">
                <label for="fullname" class="form-label">Full Name</label>
                <input type="text" class="form-control" name="fullname" required>
              </div>
              <div class="col-md-3">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" class="form-control" name="dob" required>
              </div>
              <div class="col-md-3">
                <label for="gender" class="form-label">Gender</label>
                <select class="form-select" name="gender" required>
                  <option value="">Select</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="contactNumber" class="form-label">Contact Number</label>
                <input type="text" class="form-control" name="contactNumber" required>
              </div>
              <div class="col-md-6">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" name="email" required>
              </div>
            </div>

            <div class="row mb-3">
              <div class="col-md-6">
                <label for="address" class="form-label">Address</label>
                <input type="text" class="form-control" name="address" required>
              </div>
              <div class="col-md-6">
                <label for="barangay" class="form-label">Barangay</label>
                <input type="text" class="form-control" name="barangay" required>
              </div>
            </div>

            <div class="row mb-4">
              <div class="col-md-6">
                <label for="expiry_date" class="form-label">Membership Expiry Date</label>
                <input type="date" class="form-control" name="expiry_date" required>
              </div>
            </div>
          </div>

          <div class="card-footer">
            <button type="submit" class="btn btn-success">Submit</button>
            <a href="youth.php" class="btn btn-secondary">Back</a>
          </div>
        </form>
      </div>

    </div>
  </div>
  <footer class="text-center py-3">
  <small>&copy; <?php echo date('Y'); ?> BIN. SK FEDERATION. All rights reserved.</small>
</footer>
</div>

</body>
</html>
