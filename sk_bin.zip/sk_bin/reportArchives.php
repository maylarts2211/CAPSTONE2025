<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
?>

<div class="container mt-5">
    <h2 class="text-center">Report Archive</h2>
    <p class="text-center">Browse through the historical reports and data of the SK Federation across various barangays. This archive provides insight into the progress and financial activities that have been recorded over the years.</p>

    <div class="row">
        <!-- Example of listing archived reports -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-file-invoice-dollar"></i> Financial Report 2023</h5>
                    <p class="card-text">A detailed report on financial activities for the year 2023.</p>
                    <a href="reports/financial_report_2023.pdf" class="btn btn-primary" target="_blank">
                        <i class="fas fa-download"></i> View Report
                    </a>
                </div>
            </div>
        </div>

        <!-- Another Example -->
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5 class="card-title"><i class="fas fa-chart-line"></i> Barangay Progress Report - 2022</h5>
                    <p class="card-text">Summary of development activities in various barangays for the year 2022.</p>
                    <a href="reports/barangay_progress_2022.pdf" class="btn btn-primary" target="_blank">
                        <i class="fas fa-download"></i> View Report
                    </a>
                </div>
            </div>
        </div>

        <!-- Add more report cards as needed -->
    </div>
</div>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
