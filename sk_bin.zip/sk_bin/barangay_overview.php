<?php
 include('includes/header.php');
 include('includes/navbar.php');
 include('includes/topbar.php');
 ?>

    

<div class="container my-5">
  <h2 class="mb-4 text-center">📊 Overall Accomplishments vs Goals</h2>
  <div class="card shadow-sm p-4">
    <canvas id="overallChart"></canvas>
  </div>
</div>


<div class="container my-5">
  <h2 class="mb-4">📈 Progress Monitoring by Barangay</h2>
  <div class="row row-cols-1 row-cols-md-4 g-4">

    <!-- Barangay Card Example -->
    <div class="col">
      <div class="card h-100">
        <div class="card-body">
          <h5 class="card-title">Barangay 1</h5>
          <p class="card-text">Click to view progress</p>
          <button class="btn btn-primary btn-sm" data-bs-toggle="collapse" data-bs-target="#brgy1-details">
            View Details
          </button>
        </div>
      </div>
    </div>

    <!-- Repeat similar cards for Barangays 2–16 -->
    <!-- You can loop these dynamically if using a framework -->

  </div>

  <!-- Barangay 1 Progress Details (Collapsed Section) -->
  <div class="collapse mt-4" id="brgy1-details">
    <div class="card card-body">
      <h5>Barangay 1 – Project Completion</h5>

      <p class="mt-3 mb-1">Leadership Training</p>
      <div class="progress mb-3">
        <div class="progress-bar bg-success" style="width: 85%;">85%</div>
      </div>

      <p class="mb-1">Youth Sports League</p>
      <div class="progress mb-3">
        <div class="progress-bar bg-warning" style="width: 60%;">60%</div>
      </div>

      <p class="mb-1">Clean-Up Drive</p>
      <div class="progress mb-3">
        <div class="progress-bar bg-danger" style="width: 45%;">45%</div>
      </div>
    </div>
  </div>
</div>


  
<?php

include('includes/footer.php');
?>

<script>
  const ctx = document.getElementById('overallChart').getContext('2d');

  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: [
        'Barangay 1', 'Barangay 2', 'Barangay 3', 'Barangay 4',
        'Barangay 5', 'Barangay 6', 'Barangay 7', 'Barangay 8',
        'Barangay 9', 'Barangay 10', 'Barangay 11', 'Barangay 12',
        'Barangay 13', 'Barangay 14', 'Barangay 15', 'Barangay 16'
      ],
      datasets: [
        {
          label: 'Goals',
          data: [100, 100, 100, 100, 100, 100, 100, 100],
          backgroundColor: 'rgba(54, 162, 235, 0.4)',
          borderColor: 'rgba(54, 162, 235, 1)',
          borderWidth: 1
        },
        {
          label: 'Accomplishments',
          data: [85, 90, 75, 60, 50, 95, 80, 70],
          backgroundColor: 'rgba(99, 228, 88, 0.6)',
          borderColor: 'rgba(75, 192, 192, 1)',
          borderWidth: 1
        }
      ]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true,
          max: 120,
          ticks: {
            stepSize: 20
          }
        }
      }
    }
  });
</script>