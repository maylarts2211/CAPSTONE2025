<?php
include('../includes/header.php');
include('../includes/navbar.php');
include('../includes/topbar.php');

$conn = new mysqli("localhost", "root", "", "sk_bin");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (
        isset($_POST['transaction_type'], $_POST['transaction_fund_name'], $_POST['transaction_amount'], $_POST['transaction_date_of_transaction'], $_POST['transaction_allocated_to'])
        && $_POST['transaction_fund_name'] !== ''
        && $_POST['transaction_amount'] !== ''
        && $_POST['transaction_date_of_transaction'] !== ''
        && $_POST['transaction_allocated_to'] !== ''
    ) {
        $transaction_type = $_POST['transaction_type'];
        $fund_name = trim($_POST['transaction_fund_name']);
        $amount = floatval($_POST['transaction_amount']);
        $date_of_transaction = $_POST['transaction_date_of_transaction'];
        $allocated_to = trim($_POST['transaction_allocated_to']);
        $remarks = isset($_POST['transaction_remarks']) ? trim($_POST['transaction_remarks']) : '';
        $created_at = date('Y-m-d H:i:s');

        if ($transaction_type === 'out') {
            $amount = -abs($amount);
        } else {
            $amount = abs($amount);
        }

        $stmt = $conn->prepare("INSERT INTO tbl_fund_transaction (transaction_fund_name, transaction_amount, transaction_type, transaction_date_of_transaction, transaction_allocated_to, transaction_remarks, transaction_created_at) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sdsssss", $fund_name, $amount, $transaction_type, $date_of_transaction, $allocated_to, $remarks, $created_at);
        $stmt->execute();
        $stmt->close();
    } else {
        echo "<div class='alert alert-danger'>Error: Please fill all required fields.</div>";
    }
}

$balanceResult = $conn->query("SELECT SUM(transaction_amount) AS balance FROM tbl_fund_transaction");
$balance = $balanceResult->fetch_assoc()['balance'] ?? 0;

$transactions = $conn->query("SELECT * FROM tbl_fund_transaction ORDER BY transaction_date_of_transaction DESC, transaction_created_at DESC");
?>

<!-- DataTables CSS & JS -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" />
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>

<style>
  /* Prevent table breaking and handle long text with ellipsis */
  table.dataTable td {
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 150px;
  }
  td.fund-name,
  td.allocated-to,
  td.remarks {
    max-width: 200px; /* wider for longer text */
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>

<div class="container-fluid mt-4">
  <div class="row mb-4 align-items-center">
    <div class="col-md-6 d-flex align-items-center gap-3">
      <div class="card bg-primary text-white shadow h-100 flex-grow-1">
        <div class="card-body d-flex justify-content-between align-items-center">
          <div>
            <h5 class="card-title fw-bold mb-1">Remaining Balance</h5>
            <h1 class="fw-bold mb-0">₱<?= number_format($balance, 2) ?></h1>
          </div>
        </div>
      </div>
      <div class="d-flex flex-column gap-2">
        <button class="btn btn-primary btn-lg fw-semibold" data-toggle="modal" data-target="#transactionModal" onclick="setTransactionType('in')" title="Add Funds">
          <i class="fas fa-plus"></i>
        </button>
        <button class="btn btn-danger btn-lg fw-semibold" data-toggle="modal" data-target="#transactionModal" onclick="setTransactionType('out')" title="Deduct Funds">
          <i class="fas fa-minus"></i>
        </button>
      </div>
    </div>
  </div>

  <!-- TRANSACTIONS TABLE -->
  <div class="card shadow mb-4">
    <div class="card-header bg-secondary text-white">
      <h6 class="m-0 font-weight-bold">Transaction History</h6>
    </div>
    <div class="card-body p-2">
      <div class="table-responsive p-0 m-0" style="overflow-x:auto;">
        <table id="transactionsTable" class="table table-striped table-bordered m-0" style="min-width:auto; width:100%;">
          <thead class="thead-dark text-center">
            <tr>
              <th>ID</th>
              <th>Date of Transaction</th>
              <th>Fund Name</th>
              <th>Allocated To</th>
              <th>Type</th>
              <th>Cash In</th>
              <th>Cash Out</th>
              <th>Remarks</th>
              <th>Created At</th>
            </tr>
          </thead>
          <tbody class="text-center">
            <?php if ($transactions && $transactions->num_rows > 0): ?>
              <?php while ($row = $transactions->fetch_assoc()): ?>
                <tr>
                  <td><?= $row['transaction_id'] ?></td>
                  <td><?= htmlspecialchars($row['transaction_date_of_transaction']) ?></td>
                  <td class="fund-name"><?= htmlspecialchars($row['transaction_fund_name']) ?></td>
                  <td class="allocated-to"><?= htmlspecialchars($row['transaction_allocated_to']) ?></td>
                  <td><?= htmlspecialchars(ucfirst($row['transaction_type'])) ?></td>
                  <td class="text-success text-end"><?= $row['transaction_amount'] > 0 ? '₱' . number_format($row['transaction_amount'], 2) : '' ?></td>
                  <td class="text-danger text-end"><?= $row['transaction_amount'] < 0 ? '₱' . number_format(abs($row['transaction_amount']), 2) : '' ?></td>
                  <td class="remarks"><?= htmlspecialchars($row['transaction_remarks']) ?></td>
                  <td><?= htmlspecialchars($row['transaction_created_at']) ?></td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr><td colspan="9">No transactions recorded.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ADD/DEDUCT Transaction Modal -->
<div class="modal fade" id="transactionModal" tabindex="-1" role="dialog" aria-labelledby="transactionModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <form method="POST" class="modal-content" id="transactionForm">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title" id="transactionModalLabel">Add / Deduct Funds</h5>
        <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close"><span>&times;</span></button>
        <!-- For Bootstrap 5, consider: <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button> -->
      </div>
      <div class="modal-body">
        <input type="hidden" name="transaction_type" id="transaction_type" value="in" required>
        <div class="form-group mb-3">
          <label for="transaction_fund_name">Fund Name</label>
          <input type="text" id="transaction_fund_name" name="transaction_fund_name" class="form-control" required>
        </div>
        <div class="form-group mb-3">
          <label for="transaction_allocated_to">Allocated To</label>
          <input type="text" id="transaction_allocated_to" name="transaction_allocated_to" class="form-control" required>
        </div>
        <div class="form-group mb-3">
          <label for="transaction_amount">Amount (₱)</label>
          <input type="number" id="transaction_amount" name="transaction_amount" class="form-control" min="0" step="0.01" required>
        </div>
        <div class="form-group mb-3">
          <label for="transaction_date_of_transaction">Date of Transaction</label>
          <input type="date" id="transaction_date_of_transaction" name="transaction_date_of_transaction" class="form-control" required value="<?= date('Y-m-d') ?>">
        </div>
        <div class="form-group mb-3">
          <label for="transaction_remarks">Remarks</label>
          <textarea id="transaction_remarks" name="transaction_remarks" class="form-control" rows="3"></textarea>
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-success" type="submit">Save</button>
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
      </div>
    </form>
  </div>
</div>

<script>
function setTransactionType(type) {
  document.getElementById('transaction_type').value = type;
  if(type === 'in') {
    document.getElementById('transactionModalLabel').innerText = "Add Funds";
  } else {
    document.getElementById('transactionModalLabel').innerText = "Deduct Funds";
  }
}

$(document).ready(function() {
  $('#transactionsTable').DataTable({
    order: [[1, 'desc']],
    responsive: true,
    pageLength: 10,
    lengthMenu: [5, 10, 25, 50, 100],
    columnDefs: [
      { targets: [5, 6], className: 'dt-body-right' }
    ]
  });

  // Modal close button fix for Bootstrap 4/5
  $('.modal .close').on('click', function() {
    $(this).closest('.modal').modal('hide');
  });
});
</script>

<?php include('../includes/footer.php'); ?>
