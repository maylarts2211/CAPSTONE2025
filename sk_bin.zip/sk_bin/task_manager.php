<?php
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
?>

<style>
    @media print {
        body * {
            visibility: hidden;
        }

        #task-table, #task-table * {
            visibility: visible;
        }

        #task-table {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }

        .no-print {
            display: none !important;
        }
    }

    .table td, .table th {
        vertical-align: middle;
        white-space: nowrap;
        font-size: 0.875rem;
        padding: 0.5rem 1rem;
    }

    @media (max-width: 768px) {
        .table-responsive {
            font-size: 0.8rem;
        }
    }
</style>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <a href="add_task.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Add Event
        </a>
    </div>

    <div class="row mb-3 no-print">
        <div class="col-md-4">
            <input type="text" id="searchInput" class="form-control" placeholder="Search tasks...">
        </div>
        <div class="col-md-4">
            <div class="input-group">
                <select id="statusFilter" class="form-control">
                    <option value="">All Status</option>
                    <option value="Ongoing">Ongoing</option>
                    <option value="Completed">Completed</option>
                    <option value="Pending">Pending</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
                <select id="taskFilter" class="form-control ml-2">
                    <option value="all">Show All</option>
                    <option value="5">Show 5</option>
                    <option value="10">Show 10</option>
                    <option value="15">Show 15</option>
                </select>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-12">
            <div class="card shadow mb-4" id="task-table">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Events & Activities</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0" style="white-space: nowrap;">
                            <thead class="thead-dark">
                                <tr>
                                    <th>ID</th>
                                    <th>Project Title</th>
                                    <th>Barangay</th>
                                    <th>Total Budget</th>
                                    <th>Due Date</th>
                                    <th>Date Implemented</th>
                                    <th>Youth Benefited</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $tasks = [
                                    ["Clean-up Drive", "Brgy. San Isidro", 7000, 70, "Ongoing"],
                                    ["Road Repair", "Brgy. San Juan", 5000, 50, "Ongoing"],
                                    ["New Park Construction", "Brgy. Malaya", 15000, 30, "Ongoing"],
                                    ["Community Center Painting", "Brgy. Bayani", 10000, 20, "Pending"],
                                    ["Streetlight Installation", "Brgy. Poblacion", 3000, 90, "Ongoing"],
                                    ["Repainting of Bridge", "Brgy. Longos", 5000, 10, "Pending"],
                                    ["Drainage System Upgrade", "Brgy. Katipunan", 8000, 60, "Ongoing"],
                                    ["Sidewalk Repair", "Brgy. Malabon", 2000, 80, "Ongoing"],
                                    ["Basketball Court Rehab", "Brgy. Mabini", 4000, 45, "Ongoing"],
                                    ["Sewer Cleanup", "Brgy. Rizal", 3000, 25, "Pending"],
                                    ["Vegetation Trimming", "Brgy. Kalayaan", 2000, 55, "Ongoing"],
                                    ["Barangay Hall Renovation", "Brgy. Makisig", 12000, 40, "Ongoing"],
                                    ["Tree Planting", "Brgy. Maligaya", 1000, 35, "Ongoing"],
                                    ["Health Center Construction", "Brgy. Kalusugan", 25000, 15, "Pending"],
                                    ["Evacuation Drill", "Brgy. Bantay", 0, 100, "Completed"],
                                    ["Fire Hydrant Installation", "Brgy. Bagong Buhay", 4000, 60, "Ongoing"]
                                ];

                                $dateDue = "2025-05-30";
                                $dateImplemented = "2025-04-10";
                                foreach ($tasks as $index => $task) {
                                    $status = $task[4];
                                    $badgeClass = $status === "Ongoing" ? "badge-success" :
                                        ($status === "Completed" ? "badge-primary" :
                                            ($status === "Cancelled" ? "badge-dark" : "badge-danger"));

                                    echo "<tr>
                                        <td>" . ($index + 1) . "</td>
                                        <td>{$task[0]}</td>
                                        <td>{$task[1]}</td>
                                        <td>₱" . number_format($task[2], 2) . "</td>
                                        <td>{$dateDue}</td>
                                        <td>{$dateImplemented}</td>
                                        <td>{$task[3]}</td>
                                        <td><span class='badge {$badgeClass}'>{$status}</span></td>
                                        <td>
                                            <button class='btn btn-success btn-complete'>Complete</button>
                                            <button class='btn btn-danger btn-cancel'>Cancel</button>
                                        </td>
                                    </tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="text-left mt-4 no-print">
                        <button onclick="window.print()" class="btn btn-secondary">
                            <i class="fas fa-print"></i> Print Task Table
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function applyFilters() {
        const searchInput = document.getElementById("searchInput").value.toUpperCase();
        const statusFilter = document.getElementById("statusFilter").value.toUpperCase();
        const taskFilter = document.getElementById("taskFilter").value;

        const table = document.getElementById("dataTable");
        const rows = table.getElementsByTagName("tr");

        let shownCount = 0;

        for (let i = 1; i < rows.length; i++) {
            const row = rows[i];
            const tds = row.getElementsByTagName("td");
            const txtValue = row.textContent || row.innerText;
            const statusValue = tds[7]?.textContent.toUpperCase() || "";

            const matchesSearch = txtValue.toUpperCase().includes(searchInput);
            const matchesStatus = !statusFilter || statusValue.includes(statusFilter);

            if (matchesSearch && matchesStatus) {
                if (taskFilter === "all" || shownCount < parseInt(taskFilter)) {
                    row.style.display = "";
                    shownCount++;
                } else {
                    row.style.display = "none";
                }
            } else {
                row.style.display = "none";
            }
        }
    }

    document.addEventListener("DOMContentLoaded", () => {
        document.getElementById("searchInput").addEventListener("keyup", applyFilters);
        document.getElementById("statusFilter").addEventListener("change", applyFilters);
        document.getElementById("taskFilter").addEventListener("change", applyFilters);

        document.querySelectorAll(".btn-complete").forEach(button => {
            button.addEventListener("click", function () {
                const row = this.closest("tr");
                const statusCell = row.querySelector("td:nth-child(8) span");
                statusCell.textContent = "Completed";
                statusCell.className = "badge badge-primary";
            });
        });

        document.querySelectorAll(".btn-cancel").forEach(button => {
            button.addEventListener("click", function () {
                const row = this.closest("tr");
                const statusCell = row.querySelector("td:nth-child(8) span");
                statusCell.textContent = "Cancelled";
                statusCell.className = "badge badge-dark";
            });
        });
    });
</script>

<?php include('includes/footer.php'); ?>
