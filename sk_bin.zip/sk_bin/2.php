<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "sk_bin"); // Adjust as needed

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch barangays from the barangay table
$barangayOptions = '';
$sql = "SELECT id, brgy_name FROM barangay ORDER BY brgy_name ASC";
$result = $conn->query($sql);

// Check if there are results and create the dropdown options
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $barangayOptions .= '<option value="' . htmlspecialchars($row['id']) . '">' . htmlspecialchars($row['brgy_name']) . '</option>';
    }
}

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture form data
    $barangay_id = $_POST['barangay'];
    $last_name = $_POST['last_name'];
    $first_name = $_POST['first_name'];
    $middle_name = $_POST['middle_name'];
    $suffix = $_POST['suffix'];
    $birth_date = $_POST['birth_date'];
    $birth_place = $_POST['birth_place'];
    $sex = $_POST['sex'];
    $civil_status = $_POST['civil_status'];
    $religion = $_POST['religion'];
    $address = $_POST['address'];
    $tel_no = $_POST['tel_no'];
    $mobile_no = $_POST['mobile_no'];
    $barangay_tel_no = $_POST['barangay_tel_no'];
    $email = $_POST['email'];
    $occupation = isset($_POST['occupation']) ? $_POST['occupation'] : NULL;  // Handle occupation as optional
    $education = $_POST['education'];  // Multiple values, so it might be an array

    // Insert into officials table
    $stmt = $conn->prepare("INSERT INTO officials (barangay_id, last_name, first_name, middle_name, suffix, birth_date, birth_place, sex, civil_status, religion, address, tel_no, mobile_no, barangay_tel_no, email, occupation) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    if ($stmt === false) {
        die('Prepare failed: ' . $conn->error);
    }

    // Bind parameters, check for optional occupation field
    $stmt->bind_param("issssssssssssss", $barangay_id, $last_name, $first_name, $middle_name, $suffix, $birth_date, $birth_place, $sex, $civil_status, $religion, $address, $tel_no, $mobile_no, $barangay_tel_no, $email, $occupation);

    if ($stmt->execute() === false) {
        die('Execute failed: ' . $stmt->error);
    }

    // Get the last inserted official_id
    $official_id = $stmt->insert_id;
    $stmt->close();

    // Insert into official_educations table
    foreach ($education as $edu_level) {
        $edu_stmt = $conn->prepare("INSERT INTO official_educations (official_id, education_id) VALUES (?, ?)");
        if ($edu_stmt === false) {
            die('Prepare failed: ' . $conn->error);
        }

        // Assuming that the education levels are stored as integers in the 'education' table
        $education_id = (int)$edu_level; // Adjust as needed based on the type of $edu_level
        $edu_stmt->bind_param("ii", $official_id, $education_id);

        if ($edu_stmt->execute() === false) {
            die('Execute failed: ' . $edu_stmt->error);
        }

        $edu_stmt->close();
    }

    // Insert into education_details table (for detailed education information)
    if (!empty($_POST['education_specify'])) {
        $edu_details_stmt = $conn->prepare("INSERT INTO education_details (official_id, details) VALUES (?, ?)");
        if ($edu_details_stmt === false) {
            die('Prepare failed: ' . $conn->error);
        }
        $edu_specify = $_POST['education_specify'];
        $edu_details_stmt->bind_param("is", $official_id, $edu_specify);

        if ($edu_details_stmt->execute() === false) {
            die('Execute failed: ' . $edu_details_stmt->error);
        }

        $edu_details_stmt->close();
    }

    // Insert positions if any
    if (!empty($_POST['position'])) {
        foreach ($_POST['position'] as $position) {
            // Insert into official_positions table
            $position_stmt = $conn->prepare("INSERT INTO official_positions (official_id, position_id, rank) VALUES (?, ?, ?)");
            if ($position_stmt === false) {
                die('Prepare failed: ' . $conn->error);
            }

            // Assuming that 'position' values are stored as integers, adjust as necessary
            $position_id = (int)$position; // Adjust this according to your positions table
            $rank = isset($_POST['rank']) ? $_POST['rank'] : NULL; // Handle rank if provided

            $position_stmt->bind_param("iii", $official_id, $position_id, $rank);

            if ($position_stmt->execute() === false) {
                die('Execute failed: ' . $position_stmt->error);
            }

            $position_stmt->close();
        }
    }

    echo "Data submitted successfully!";
}

echo '
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barangay Official\'s Information Sheet</title>

    <!-- Bootstrap core CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/gh/StartBootstrap/startbootstrap-sb-admin-2@gh-pages/css/sb-admin-2.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <div class="text-center mb-4">
        <h5>Republic of the Philippines</h5>
        <h6>Department of the Interior and Local Government</h6>
        <p>DILG-NAPOLCOM Center, Binalbagan</p>
        <h4 class="font-weight-bold mt-4">SK OFFICIAL\'S INFORMATION SHEET</h4>
    </div>

    <form method="POST" action="">
        <p><strong>REGION:</strong> NIR &nbsp;&nbsp;&nbsp;&nbsp; <strong>CITY/MUN:</strong>BINALBAGAN</p>
        <p><strong>PROVINCE:</strong>NIR &nbsp;&nbsp;&nbsp;&nbsp; <strong>BARANGAY:</strong> 
            <select class="form-control" name="barangay">
                <option value="">Select Barangay</option>' 
                . $barangayOptions . 
            '</select>
        </p>

        <hr>
        <h5><strong>ELECTIVE AND APPOINTIVE POSITION</strong></h5>
        <div>
            <div><input type="checkbox" name="position[]" value="1"> Sangguniang Barangay Member - Rank (1,2,3...): <input type="text" class="form-control d-inline-block w-auto" name="rank[]"></div>
            <div><input type="checkbox" name="position[]" value="2"> SK Chairperson</div>
            <div><input type="checkbox" name="position[]" value="3"> SK Member</div>
            <div><input type="checkbox" name="position[]" value="4"> SK Secretary</div>
            <div><input type="checkbox" name="position[]" value="5"> SK Treasurer</div>
        </div>
    

        <hr>
        <h5><strong>PERSONAL INFORMATION</strong></h5>
        <div class="row">
            <div class="col-md-4">Last Name: <input type="text" class="form-control" name="last_name"></div>
            <div class="col-md-4">First Name: <input type="text" class="form-control" name="first_name"></div>
            <div class="col-md-4">Middle Name: <input type="text" class="form-control" name="middle_name"></div>
        </div>
        <div class="row mt-2">
            <div class="col-md-4">Suffix: <input type="text" class="form-control" name="suffix"></div>
            <div class="col-md-4">Birth Date: <input type="date" class="form-control" name="birth_date"></div>
            <div class="col-md-4">Birth Place: <input type="text" class="form-control" name="birth_place"></div>
        </div>
        <div class="row mt-2">
            <div class="col-md-3">Sex: <input type="text" class="form-control" name="sex"></div>
            <div class="col-md-3">Civil Status: <input type="text" class="form-control" name="civil_status"></div>
            <div class="col-md-3">Religion: <input type="text" class="form-control" name="religion"></div>
        </div>

        <div class="row mt-3">
            <div class="col-md-6">Residence Address: <input type="text" class="form-control" name="address"></div>
            <div class="col-md-6">Residence Telephone No.: <input type="text" class="form-control" name="tel_no"></div>
        </div>
        <div class="row mt-2">
            <div class="col-md-4">Mobile Number: <input type="text" class="form-control" name="mobile_no"></div>
            <div class="col-md-4">Barangay Hall Tel. No.: <input type="text" class="form-control" name="barangay_tel_no"></div>
            <div class="col-md-4">Email Address: <input type="email" class="form-control" name="email"></div>
        </div>

        <hr>
        <h5><strong>EDUCATIONAL ATTAINMENT</strong></h5>
        <div>
            <input type="checkbox" name="education[]" value="1"> High School Graduate
            <input type="checkbox" name="education[]" value="2"> College Graduate
            <input type="checkbox" name="education[]" value="3"> Post Graduate
            <input type="text" class="form-control mt-2" name="education_specify" placeholder="If specify your level">
        </div>

        <hr>
        <div>
            <button type="submit" class="btn btn-primary mt-3">Submit</button>
        </div>
    </form>
</div>

</body>
</html>';
?>
