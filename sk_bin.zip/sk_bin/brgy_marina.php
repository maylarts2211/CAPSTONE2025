<?php
// Include your layout and config
include('includes/header.php');
include('includes/navbar.php');
include('includes/topbar.php');
include('includes/connect.php');
?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Barangay Bagroy</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #aaa;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #2c7be5;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        h2 {
            text-align: center;
            margin-top: 30px;
        }
        .button-container {
            width: 90%;
            margin: 20px auto;
            text-align: left;
        }
        .button-container .btn {
            margin: 10px 0;
            border-radius: 12px;
            font-size: 16px;
            padding: 12px 24px;
            transition: all 0.3s ease;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }
        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }
        .btn-secondary {
            background-color: #6c757d;
            border-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
            border-color: #545b62;
        }
        .btn-close {
            background-color: transparent;
            border: none;
            color: #fff;
            font-size: 1.25rem;
        }
        .btn-close:hover {
            color: #007bff;
        }

        .modal-header, .modal-footer {
            display: flex;
            justify-content: space-between;
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            padding: 1rem 2rem;
        }

        .modal-body {
            padding: 2rem;
        }
    </style>
</head>
<body>

<h2>Barangay Marina</h2>

<!-- Button to trigger modal with enhanced styling -->
<div class="button-container">
    <button class="popup-button btn btn-primary" data-bs-toggle="modal" data-bs-target="#addOfficerModal">Add Officer</button>
</div>

<!-- Officer Table -->
<table>
    <thead>
        <tr>
            <th>Position</th>
            <th>Name</th>
            <th>Barangay</th>
            <th>Term (Start - End)</th>
            <th>Status</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Query the sk_federation_officers table
        $query = "SELECT * FROM sk_federation_officers";
        $query_run = mysqli_query($conn, $query);

        if (mysqli_num_rows($query_run) > 0) {
            foreach ($query_run as $officer) {
                echo "<tr>";
                echo "<td><a href='officer_view.php?id=" . urlencode($officer['id']) . "'>" . htmlspecialchars($officer['position']) . "</a></td>";
                echo "<td>" . htmlspecialchars($officer['name']) . "</td>";
                echo "<td>" . htmlspecialchars($officer['barangay']) . "</td>";
                echo "<td>" . htmlspecialchars($officer['term_start']) . " - " . htmlspecialchars($officer['term_end']) . "</td>";
                echo "<td>" . htmlspecialchars($officer['status']) . "</td>";
                echo "<td>";
                echo "<a href='edit_officer.php?id=" . urlencode($officer['id']) . "' class='btn btn-sm btn-warning me-1'><i class='fas fa-edit'></i> Edit</a>";
                echo "<a href='delete_officer.php?id=" . urlencode($officer['id']) . "' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this officer?\");'><i class='fas fa-trash'></i> Delete</a>";
                echo "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No federation officers found.</td></tr>";
        }
        ?>
    </tbody>
</table>

<!-- Modal for Adding Officer -->
<div class="modal fade" id="addOfficerModal" tabindex="-1" aria-labelledby="addOfficerModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="addOfficerModalLabel">Add SK Officer</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Updated form content starts here -->
                <form id="kagawadForm" method="POST" action="submit_kagawad.php">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" name="full_name" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="age">Age</label>
                        <input type="number" name="age" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="gender">Gender</label>
                        <select name="gender" class="form-control" required>
                            <option value="">--Select--</option>
                            <option>Male</option>
                            <option>Female</option>
                            <option>Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" class="form-control" required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="contact_number">Contact Number</label>
                        <input type="text" name="contact_number" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email (optional)</label>
                        <input type="email" name="email" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="education">Educational Attainment</label>
                        <input type="text" name="education" class="form-control">
                    </div>

                    <div class="form-group">
                        <label for="term_start">Term Start</label>
                        <input type="date" name="term_start" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label for="term_end">Term End</label>
                        <input type="date" name="term_end" class="form-control" required>
                    </div>

                    <div class="d-flex justify-content-end">
                        <button type="submit" class="btn btn-primary me-2">Add Officer</button>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </form>
                <!-- Updated form content ends here -->
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

<?php
// Include your footer and scripts
include('includes/scripts.php');
include('includes/footer.php');
?>
