<?php
include 'db_connection.php';

$mom_id = (int)($_POST['mom_id'] ?? 0);

if ($mom_id <= 0) {
    die("Invalid record ID.");
}

// Collect posted data safely
$mom_title = $_POST['meeting_type'];
$mom_datetime = $_POST['meeting_datetime'];
$mom_location = $_POST['location'];
$mom_presiding_officer = $_POST['presiding_officer'];
$mom_secretary = $_POST['secretary'];
$mom_attendees_count = (int)$_POST['present_count'];
$mom_agenda_summary = $_POST['agenda_summary'];
$mom_agenda_1 = $_POST['agenda_1'];
$mom_agenda_2 = $_POST['agenda_2'];
$mom_agenda_3 = $_POST['agenda_3'];
$mom_agenda_4 = $_POST['agenda_4'];
$mom_other_matters = $_POST['other_matters'];
$mom_adjournment = $_POST['adjournment'];
$mom_attachment = ''; // Handle file uploads if needed

$sql = "UPDATE tbl_mom SET
    mom_title = ?,
    mom_datetime = ?,
    mom_location = ?,
    mom_presiding_officer = ?,
    mom_secretary = ?,
    mom_attendees_count = ?,
    mom_agenda_summary = ?,
    mom_agenda_1 = ?,
    mom_agenda_2 = ?,
    mom_agenda_3 = ?,
    mom_agenda_4 = ?,
    mom_other_matters = ?,
    mom_adjournment = ?,
    mom_attachment = ?
WHERE mom_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssssissssssssi",
    $mom_title,
    $mom_datetime,
    $mom_location,
    $mom_presiding_officer,
    $mom_secretary,
    $mom_attendees_count,
    $mom_agenda_summary,
    $mom_agenda_1,
    $mom_agenda_2,
    $mom_agenda_3,
    $mom_agenda_4,
    $mom_other_matters,
    $mom_adjournment,
    $mom_attachment,
    $mom_id
);

if ($stmt->execute()) {
    echo "Record updated successfully.";
    // Optionally redirect back to the listing page:
    // header("Location: list_mom.php");
    // exit;
} else {
    echo "Error updating record: " . $stmt->error;
}

$stmt->close();
