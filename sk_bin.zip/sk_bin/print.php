<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Youth Resume Profile - Display Only</title>
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f8f9fc;
      margin: 0;
      padding: 20px;
    }
    .profile-container {
      max-width: 900px;
      margin: 30px auto;
      background: white;
      border-radius: 10px;
      box-shadow: 0 0 12px rgba(0,0,0,0.12);
      padding: 30px 40px;
      box-sizing: border-box;
      display: flex;
      gap: 40px;
      font-size: 15px;
    }
    .photo-box {
      flex: 0 0 250px;
      border: 2px dashed #ced4da;
      border-radius: 10px;
      height: 300px;
      background: #e9ecef;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
    }
    .photo-box img {
      max-width: 100%;
      max-height: 100%;
      object-fit: cover;
      border-radius: 10px;
    }
    .profile-details {
      flex: 1;
    }
    .profile-details h2 {
      margin-top: 0;
      margin-bottom: 5px;
      color: #4e73df;
      font-weight: 700;
    }
    .profile-details h4 {
      margin-bottom: 10px;
      border-bottom: 2px solid #4e73df;
      padding-bottom: 4px;
      color: #4e73df;
    }
    .info-row {
      margin-bottom: 12px;
    }
    .info-label {
      font-weight: 700;
      color: #343a40;
      width: 140px;
      display: inline-block;
    }
    /* Responsive */
    @media (max-width: 768px) {
      .profile-container {
        flex-direction: column;
      }
      .photo-box {
        width: 100%;
        height: auto;
      }
    }
  </style>
</head>
<body>

<div class="profile-container">
  <div class="photo-box">
    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJv28G_0oK1p-CKBX8J_AZAOZBRmCpGjP-6w&s" alt="Profile Photo" />
  </div>
  <div class="profile-details">
    <h2>Juan Dela Cruz Jr.</h2>
    <h4>Youth Resume Profile</h4>

    <div class="info-row"><span class="info-label">Age:</span> 18-24</div>
    <div class="info-row"><span class="info-label">Sex:</span> Male</div>
    <div class="info-row"><span class="info-label">Contact:</span> 0917-123-4567</div>
    <div class="info-row"><span class="info-label">Email:</span> juan.delacruz@example.com</div>
    <div class="info-row"><span class="info-label">Registered Voter:</span> Yes</div>
    <div class="info-row"><span class="info-label">Highest Education:</span> Senior HS, Vocational</div>
    <div class="info-row"><span class="info-label">Working in:</span> Private</div>
    <div class="info-row"><span class="info-label">Duration:</span> 2 years</div>
    <div class="info-row"><span class="info-label">Skills:</span> Microsoft Office, Graphic Design</div>
    <div class="info-row"><span class="info-label">Interests:</span> Sports, Music</div>
  </div>
</div>

</body>
</html>
